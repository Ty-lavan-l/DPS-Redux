const baseUrl = require('axios').create({
    baseURL: 'http://10.10.20.59:8080/api/v1'
});


const sparkUrl = require('axios').create({
    baseURL: 'http://10.10.20.59:4567'
});

export { sparkUrl, baseUrl }