import React, { useState } from "react";
import { Redirect } from "react-router-dom";
import ConfirmDialog from "../controls/ConfirmDialog";
import Registration from "./Registration";
import { useSelector, useDispatch } from 'react-redux';
import {LoginAuthentication} from '../../redux/actions/login-Actions'
import { loginActions } from "../../redux/reducers/loginReducer";
function LoginPage() {
  const [email, setEmail] = useState("");
  const toggle = useSelector((state) => state.login.loginPage);

  const [values, setValues] = React.useState({
    password: "",
    showPassword: false,
  });
  
  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    title: "",
    subTitle: "",
  });
  
  const dispatch = useDispatch();
  const handlePasswordChange = (prop) => (event) => {
    setValues({ ...values, [prop]: event.target.value });
  };

  const login = (e) => {
    e.preventDefault()
    const loginData = { 
      mailId : email,
      password: values.password
    }
    dispatch(LoginAuthentication(loginData));
  }


  const registerationPage = (e) => {
    e.preventDefault()
    dispatch(loginActions.RegistrationPage());
  }

  if (localStorage.getItem("token")) {
    return <Redirect to="/dashboard" />;
  }


    return <>
    {toggle && 
        <>
        <div className="login_body">
          <div className="container login_container">
            <div>
              <h1 className="login_h1 font-weight-bold ">
                Data Processing <span> Software Application</span>
              </h1>
            </div>
  
            <div className="box login_box ">
              <div className="ml-4">
                <h3 id="login_h3">
                  <strong>Login Form</strong>
                </h3>
              </div>
              <form className="card-body login_card-body" onSubmit={login}>
                <div className="input-group form-group " id="login_input">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i class="fas fa-envelope"></i>
                    </span>
                  </div>
                  <input
                    type="text"
                    pattern="[^' ']+"
                    title="No empty space allowed"
                    className="form-control login_input"
                    name="user_id"
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter Your Email "
                    required
                  />
                </div>
                <div className="input-group form-group " id="login_input1">
                  <div className="input-group-prepend">
                    <span className="input-group-text">
                      <i className="fas fa-key"></i>
                    </span>
                  </div>
                  <input
                    type="password"
                    className="form-control login_input"
                    value={values.password}
                    onChange={handlePasswordChange("password")}
                    placeholder="Enter Your Password "
                    required
                  />
                </div>
  
                <div className="form-group text-center">
                  <button id="login_button" type="submit">
                    Login
                  </button>
                </div>
              </form>
  
              <div className="form-group text-center">
              
                Don't Have An Account?{" "}
                  <b onClick={registerationPage} className="textcursor">Sign Up</b>
              </div>
            </div>
          </div>
        </div>
        <div>
          <ConfirmDialog
            confirmDialog={confirmDialog}
            setConfirmDialog={setConfirmDialog}
          />
        </div>
      </>
    }

    {!toggle && <Registration />}
    </>;
}

export default LoginPage;
