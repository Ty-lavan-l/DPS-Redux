import React, { useState } from "react";
import Notification from "../controls/Notification";
import ConfirmDialog from "../controls/ConfirmDialog";
import { useDispatch } from 'react-redux';
import { signUpAction } from "../../redux/actions/login-Actions";
import { loginActions } from "../../redux/reducers/loginReducer";

function Registration() {
  const data = {
    userName: "",
    mailId: "",
    password: "",
  };

  const [values, setValues] = useState(data);
  console.log("this is values ", values);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
    });
  };
  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });

  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    title: "",
    subTitle: "",
  });

  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault()
    const existUser = {
      mailId: `${values.mailId}`,
    }
    const newUser = values
    dispatch(signUpAction(existUser,newUser));
  }

const loginPage = (e) => {
  e.preventDefault()
  dispatch(loginActions.loginPage());
}
  return (
    <>
      <div className="login_body">
        <div className="container login_container">
          <div>
            <h1 className="login_h1 font-weight-bold ">
              Data Processing <span> Software Application</span>
            </h1>
          </div>

          <div className="box login_box ">
            <div className="ml-4">
              <h3 id="login_h3">
                <strong>Registration Form</strong>
              </h3>
            </div>
            <form className="card-body login_card-body" onSubmit={handleSubmit}>
              <div className="input-group form-group " id="login_input">
                <div className="input-group-prepend">
                  <span className="input-group-text">
                    <i className="fas fa-user"></i>
                  </span>
                </div>
                <input
                  type="text"
                  pattern="[^' ']+"
                  title="No empty space allowed"
                  className="form-control login_input"
                  name="userName"
                  value={values.userName}
                  onChange={handleInputChange}
                  placeholder="Enter your Fullname "
                  required
                />
              </div>
              <div className="input-group form-group " id="login_input">
                <div className="input-group-prepend">
                  <span className="input-group-text">
                    <i class="fas fa-envelope"></i>
                  </span>
                </div>
                <input
                  type="email"
                  pattern="[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,63}$"
                  title="Invalid Email eg: example@email.com"
                  className="form-control login_input"
                  name="mailId"
                  value={values.mailId}
                  onChange={handleInputChange}
                  placeholder="Enter Your Email "
                  required
                />
              </div>
              <div className="input-group form-group " id="login_input1">
                <div className="input-group-prepend">
                  <span className="input-group-text">
                    <i className="fas fa-key"></i>
                  </span>
                </div>
                <input
                  type="password"
                  className="form-control login_input"
                  name="password"
                  value={values.password}
                  onChange={handleInputChange}
                  placeholder="Enter New Password "
                  required
                />
              </div>

              <div className="form-group text-center">
                <button id="login_button" type="submit">
                  Submit
                </button>
              </div>
              <div className="form-group text-center">
                Already Have An Account?{" "}
                  <b onClick={loginPage} className="textcursor">Login</b>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div>
        <Notification notify={notify} setNotify={setNotify} />
        <ConfirmDialog
          confirmDialog={confirmDialog}
          setConfirmDialog={setConfirmDialog}
        />
      </div>
    </>
  );
}

export default Registration;
