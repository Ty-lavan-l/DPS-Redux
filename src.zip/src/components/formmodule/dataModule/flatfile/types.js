const SheetJSFT = [
	"xlsx", "xlsb", "xlsm", "xls", "xml"
].map(function(x) { return "." + x; }).join(",");