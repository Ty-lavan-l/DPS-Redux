import React, { createContext } from "react";
import XLSX from "xlsx";
import { make_cols } from "./MakeColumns";
import { SheetJSFT } from "./types";
import { JsonToTable } from "react-json-to-table";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import { Redirect } from "react-router-dom";
import axios from "axios";
import { Button } from "react-bootstrap";
import CloudUploadIcon from "@material-ui/icons/CloudUpload";
import { baseUrl } from "../../../controls/axios";

const UserContext = createContext({
  data: [],
});

class ExcelReader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      file: {},
      data: [],
      cols: [],
      redirect: false,
      count: 0,
      fileName: "",
    };
    this.handleFile = this.handleFile.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  setRedirect = () => {
    this.setState({
      redirect: true,
    });
  };
  renderRedirect = () => {
    if (this.state.redirect) {
      return <Redirect to="/develope" />;
    }
  };
  handleChange(e) {
    const files = e.target.files;
    if (files && files[0]) this.setState({ file: files[0] });
    this.setState({ fileName: files[0].name });
    localStorage.setItem("fileName", files[0].name);
  }
  handleFile() {
    this.setState({
      count: 1,
    });

    const reader = new FileReader();
    const rABS = !!reader.readAsBinaryString;
    reader.onload = (e) => {
      const bstr = e.target.result;
      const wb = XLSX.read(bstr, {
        type: rABS ? "binary" : "array",
        bookVBA: true,
      });

      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];

      const data = XLSX.utils.sheet_to_json(ws);

      this.setState({ data: data, cols: make_cols(ws["!ref"]) }, () => {
        console.log(JSON.stringify(this.state.data, null, 2));
      });

      localStorage.setItem("Json", JSON.stringify(this.state.data));
      localStorage.setItem("result", JSON.stringify(this.state.data));
    };

    if (rABS) {
      reader.readAsBinaryString(this.state.file);
    } else {
      reader.readAsArrayBuffer(this.state.file);
    }
    if (this.state.count == 1) {
      this.setState({
        count: 0,
      });
      const userId = localStorage.getItem("userId");
      const formData = new FormData();
      formData.append("File", this.state.file);
      baseUrl
        .post(`/data-source/upload/user/${userId}`, formData ,{
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          }
        })
        .then((res) => {
          console.log(res.data);

          localStorage.setItem(
            "flatfile",
            JSON.stringify([
              {
                title: `${res.data.data[0].datasourceName}`,
                key: `${res.data.data[0].datasourceId}`,
              },
            ])
          );
          localStorage.setItem("flatkey", res.data.data[0].datasourceId);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  render() {
    return (
      <>
        <div>
          <label htmlFor="file">
            <b className="h4">Upload An Excel To Process Triggers</b>
          </label>
          <br />

          <label
            className="
           custom-file-upload
          "
          >
            <input
              className="btn"
              type="file"
              className="form-control"
              id="file"
              accept={SheetJSFT}
              onChange={this.handleChange}
            />
            <CloudUploadIcon />
            UPLOAD
          </label>
          <p className="h6 ml-1">{this.state.fileName}</p>

          <br />
          <input
            type="submit"
            className="custom-file-uploads"
            onClick={this.handleFile}
            value="Click to Load"
          />
          <Link
            type="submit"
            onClick={this.handleFile}
            className="btn btn-primary linkbtn"
            role="button"
            to="/flatfile"
          >
            Submit
          </Link>
        </div>
      </>
    );
  }
}

export default ExcelReader;
