import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { Form } from "../../controls/useForm";
import {
  makeStyles,
} from "@material-ui/core";
import { baseUrl } from "../../controls/axios";
import { useDispatch,useSelector } from 'react-redux';
import { sqlScript } from "../../../redux/actions/develope-Actions";


export default function SqlScript({ open, handleClose, title }) {
  const data = {
    fileName: "",
    workspaceId: localStorage.getItem('workspaceId')
  };

  const [values, setValues] = useState(data);

  const [msg, setMsg] = useState("");
  const dependency = useSelector((state) => state.developeModule.sqlScript);

  useEffect(() => {
    handleClose();
    let tabarray = JSON.parse(localStorage.getItem("tab"));
    if (tabarray[0].title == "") {
      tabarray = tabarray.slice(1)
    }
    // tabarray.push({ title: `${values.fileName}`, key:`${response.data.data[0].sqlId}`})   
    tabarray.push({ title: `${values.fileName}`, key: `${Math.floor(Math.random() * (200 - 100 + 1) + 100)}` })
    localStorage.setItem("tab", JSON.stringify(tabarray))
    history.push("/develope");

    // .catch((error) => {
    //   // console.error("Something went wrong!", error);
    //   setMsg("*Provide Unique Name");
    // });

  }, [dependency]);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
      values: data,
    });
  };
  let history = useHistory();
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    setMsg("");
    e.preventDefault();
    dispatch(sqlScript(values));
  };

  return (
    <>

      <Form onSubmit={handleSubmit}>
        <div className="form-group row">
          <label
            htmlFor="fileName"
            className="col-sm-5 col-form-label sqlLable"
          >
            Name of Sql Script
          </label>
          <div className="col-sm-10">
            <p className="text-danger ml-3 small">
              {msg}</p>
            <input
              type="text"
              pattern="[^' ']+"
              title="No space allowed"
              name="fileName"
              className="form-control sqlinput"
              placeholder="Enter name of Sql Script"
              defaultValue=""
              value={values.fileName}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>
        <div>
          <button

            type="submit"
            className="btn btn-primary linkbtn"
          >
            Ok
          </button>
        </div>
      </Form>

    </>
  );
}