// import React, { useState, useEffect } from "react";
// import { useForm, Form } from "../../controls/useForm";
// import Notification from "../../controls/Notification";
// import ConfirmDialog from "../../controls/ConfirmDialog";

// import {
//   Dialog,
//   DialogTitle,
//   DialogContent,
//   makeStyles,
//   Typography,
// } from "@material-ui/core";

// import Popup from "../../controls/Popup";
// import { baseUrl } from "../../controls/axios";

// const useStyles = makeStyles((theme) => ({
//   root: {
//     "& > *": {
//       margin: theme.spacing(1),
//     },
//   },
//   dialogWrapper: {
//     padding: theme.spacing(2),
//     position: "absolute",
//     top: theme.spacing(5),
//     bottom: theme.spacing(3),
//     borderRadius: "30px",
//     width: "90vh",
//     height: "85vh",
//   },
//   dialogTitle: {
//     paddingRight: "0px",
//   },
// }));

// export default function Restapi({ open, handleClose, title }) {
//   const classes = useStyles();
//   const [hashCode, setHashCode] = useState("fsdfgfgsfg");
//   const [link, setLink] = useState("");

//   const [notify, setNotify] = useState({
//     isOpen: false,
//     message: "",
//     type: "",
//   });

//   const getApi = (e) => {
//     e.preventDefault();
//     var userId = localStorage.getItem("userId");
//     var workspaceId = localStorage.getItem("workspaceId");
//     let tabName = JSON.parse(localStorage.getItem("tab"));
//     let key = localStorage.getItem("key");
//     if (key == 0) {
//       var sqlscriptId = tabName[0].key;
//     } else {
//       let object = tabName.find((x) => x.key == key);
//       var sqlscriptId = object.key;
//     }
//     console.log(userId, workspaceId, sqlscriptId);
//     baseUrl
//       .post(`/get/apikey1`, {
//         userId,
//         workspaceId,
//         sqlscriptId,
//       })
//       .then((res) => {
//         setHashCode(
//           res.data.data
//           // 1234
//         );
//       })
//       .catch((error) => {
//         console.error("Something went wrong!", error);
//       });
//   };
//   const copyToClipboard = (e) => {
//     e.preventDefault();
//     var copyText = document.getElementById("APIkey");
//     copyText.select();
//     copyText.setSelectionRange(0, 99999);
//     document.execCommand("copy");
//     setNotify({
//       isOpen: true,
//       message: `Copied!`,
//       type: "success",
//     });
//   };
//   const getLink = (e) => {
//     e.preventDefault();
//     var api = hashCode;
//     var json = JSON.parse(sessionStorage.getItem("result"));
//     baseUrl
//       .post("/api/v1/data/insert", {
//         api,
//         json,
//       })
//       .then((res) => {
//         setLink(`http://10.10.20.59:8085/api/v1/data/fetch/${api}`);
//       })
//       .catch((error) => {
//         console.error("Something went wrong!", error);
//       });
//   };

//   return (
//     <>
//       <Form>
//         <label className="ml-3">
//           {" "}
//           <b style={{ fontSize: "18px" }}> API key:</b>
//         </label>
//         <div className="d-flex ">
//           <input
//             id="APIkey"
//             type="text"
//             value={hashCode}
//             className="form-control sqlinput col-md-8"
//             readOnly
//           />
//           <button className="btn btn-primary " onClick={copyToClipboard}>copy API key</button>
//           <span>
//             <button
//               className="btn btn-primary  sqlinput bg-primary text-white"
//               onClick={getApi}
//             >
//               Generate API key
//             </button>
//           </span>
//         </div>

//         <div>
//           <label className="ml-3 ">
//             <b style={{ fontSize: "18px" }}> REST End point:</b>
//           </label>
//         </div>
//         <div className="d-flex ">
//           <input
//             type="text"
//             className="form-control sqlinput col-md-8"
//             value={link}
//             readOnly
//           />
//           <span>
//             <button
//               className="btn btn-primary  sqlinput  bg-primary text-white"
//               onClick={getLink}
//             >
//               Generate REST API
//             </button>
//           </span>
//         </div>
//       </Form>

//       <div>
//         <Notification notify={notify} setNotify={setNotify} />
//       </div>
//     </>
//   );
// }

import React, { useState, useEffect } from "react";
import { useForm, Form } from "../../controls/useForm";
import Notification from "../../controls/Notification";
import ConfirmDialog from "../../controls/ConfirmDialog";
import FileCopyIcon from "@material-ui/icons/FileCopy";
import InputAdornment from "@material-ui/core/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import IconButton from "@material-ui/core/IconButton";
import Input from "@material-ui/core/Input";
import clsx from "clsx";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import { Switch } from "antd";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  makeStyles,
  Typography,
} from "@material-ui/core";

import Popup from "../../controls/Popup";
import { baseUrl } from "../../controls/axios";
import { TextRotationAngledown } from "@material-ui/icons";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  dialogWrapper: {
    padding: theme.spacing(2),
    position: "absolute",
    top: theme.spacing(5),
    bottom: theme.spacing(3),
    borderRadius: "30px",
    width: "90vh",
    height: "85vh",
  },
  dialogTitle: {
    paddingRight: "0px",
  },
}));
// let token = localStorage.getItem("token");
// let userId = localStorage.getItem("userId");
let workspaceId = localStorage.getItem("workspaceId");
let mailId = localStorage.getItem("mailId");
// var tabName = JSON.parse(localStorage.getItem("tab"));
// var key = localStorage.getItem("key");
// if (key == 0) {
//   var sqlId = tabName[0].title;
// } else {
//   var object = tabName.find((x) => x.key == key);
//   var sqlId = object.key;
// }
export default function Restapi({}) {
  const classes = useStyles();
  const [hashCode, setHashCode] = useState("");
  const [link, setLink] = useState("");
  const [toggle, setToggle] = useState(true);

  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });
  const copyAPI = (e) => {
    e.preventDefault();
    var copyText = document.getElementById("APIkey");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    setNotify({
      isOpen: true,
      message: `Copied!`,
      type: "success",
    });
  };
  const copyLink = (e) => {
    e.preventDefault();
    var copyText = document.getElementById("RestEndPoint");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    setNotify({
      isOpen: true,
      message: `Copied!`,
      type: "success",
    });
  };
  const getApi = (e) => {
    e.preventDefault();
    var mailId = localStorage.getItem("mailId");
    var workspaceId = localStorage.getItem("workspaceId");
    let tabName = JSON.parse(localStorage.getItem("tab"));
    let key = localStorage.getItem("key");
    if (key != null && tabName!=null && workspaceId!=null) {
      if (key == 0) {
        var sqlscriptId = tabName[0].key;
      } else {
        let object = tabName.find((x) => x.key == key);
        var sqlscriptId = object.key;
      }
    }
    console.log(mailId, workspaceId, sqlscriptId);
    baseUrl
      .post(
        `/get/apikey1`,
        {
          mailId,
          workspaceId,
          sqlscriptId,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        setHashCode(res.data.data);
      })
      .catch((error) => {
        console.error("Something went wrong!", error);
      });
  };
  const getLink = (e) => {
    e.preventDefault();
    var api = hashCode;
    var json = JSON.parse(sessionStorage.getItem("result"));
    baseUrl
      .post(
        "/api/v1/data/insert",
        {
          api,
          json,
        },
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        setLink(
          `http://10.10.20.59:8080/api/v1/data/fetch?mailId=<mailId>&password=<password>&api=${api}`
        );
      })
      .catch((error) => {
        console.error("Something went wrong!", error);
      });
  };
  const toggleFunction = (e) => {
    var api = hashCode;
    setToggle(!toggle);
    if (!toggle) {
      setLink(
        `http://10.10.20.59:8080/api/v1/data/fetch?mailId=<mailId>&password=<password>&api=${api}`
      );
    } else {
      setLink(`http://10.10.20.59:8080/api/v1/data/fetch`);
    }
  };

  return (
    <>
      <Form>
        <label className="ml-3 ">
          {" "}
          <b style={{ fontSize: "18px" }}> API key:</b>
        </label>

        <div className="d-flex ">
          <FormControl
            className={clsx(classes.margin, classes.textField)}
            variant="outlined"
            style={{ width: "70%" }}
          >
            <OutlinedInput
              id="APIkey"
              readOnly
              value={hashCode}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    onClick={copyAPI}
                    aria-label="toggle password visibility"
                    edge="end"
                  >
                    <i class="far fa-clipboard"></i>
                  </IconButton>
                </InputAdornment>
              }
            />
          </FormControl>

          <span>
            <button
              className="btn btn-primary  sqlinput bg-primary text-white"
              onClick={getApi}
            >
              Generate API
            </button>
          </span>
        </div>

        <div>
          <label className="ml-3 ">
            <b style={{ fontSize: "18px" }}> REST End point:</b>
          </label>
        </div>
        <div className="d-flex ">
          <FormControl
            className={clsx(classes.margin, classes.textField)}
            variant="outlined"
            style={{ width: "70%" }}
          >
            <OutlinedInput
              id="RestEndPoint"
              readOnly
              value={link}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    onClick={copyLink}
                    aria-label="toggle password visibility"
                    edge="end"
                  >
                    <i class="far fa-clipboard"></i>
                  </IconButton>
                </InputAdornment>
              }
            />
          </FormControl>
          <span>
            <button
              className="btn btn-primary  sqlinput  bg-primary text-white"
              onClick={getLink}
            >
              Generate Link
            </button>
          </span>
        </div>
      </Form>
      <span className="mr-4" style={{ float: "right" }}>
        <b>Append API key:</b>{" "}
        <Switch defaultChecked onClick={toggleFunction} />
      </span>

      <div>
        <Notification notify={notify} setNotify={setNotify} />
      </div>
    </>
  );
}
