import React, { useEffect, useState } from "react";
import DevelopePopup from "../../controls/DevelopePopup";
import { useForm, Form } from "../../controls/useForm";
import DevelopeDashboard from "../../develope/DevelopeDashboard";
import { useHistory } from "react-router-dom";
import axios from "axios";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  makeStyles,
  Typography,
} from "@material-ui/core";
import { baseUrl } from "../../controls/axios";
const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  dialogWrapper: {
    padding: theme.spacing(2),
    position: "absolute",
    top: theme.spacing(5),
    bottom: theme.spacing(3),
    borderRadius: "30px",
    width: "90vh",
    height: "45vh",
  },
  dialogTitle: {
    paddingRight: "0px",
  },
}));

export default function BiAnalytic(props) {
  const data = {
    fileName: "",
  };

  const classes = useStyles();
  const [values, setValues] = useState(data);
  const [openPopup, setOpenPopup] = useState(false);
  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });

  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    title: "",
    subTitle: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
      values: data,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem('tab', JSON.stringify({ title: `${values.fileName}`, key: '1' }) )
console.log(values.fileName);
    baseUrl
      .post("/bi-analytic/bianalytic", values ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
      .then((response) => {
        console.log("Status: ", response.status);
        console.log("this is axios", response.data);
        history.push("/develope");
        setNotify({
          isOpen: true,
          message: `Datasource added Successfully`,
          type: "success",
        });
      })
      .catch((error) => {
        console.error("Something went wrong!", error);
      });
  };

  let history = useHistory();

  function handleClick() {
    history.push("/develope");
  }

  return (
    <>
      <Form onSubmit={handleSubmit}>
        <div className="form-group row">
          <label
            htmlFor="fileName"
            className="col-sm-5 col-form-label sqlLable"
          >
            Name of Bi Analytic
          </label>
          <div className="col-sm-10">
            <input
              type="text"
              pattern="[^' ']+"
                title="No space allowed"
              name="fileName"
              className="form-control sqlinput"
              placeholder="Enter name of Bi Analytic"
              defaultValue=""
              value={values.fileName}
              onChange={handleInputChange}
            />
          </div>
        </div>
        <div>
          <button type="submit" className="btn btn-primary linkbtn">
            Ok
          </button>
        </div>
      </Form>
      <DevelopePopup openPopup={openPopup} setOpenPopup={setOpenPopup}>
        <DevelopeDashboard />
      </DevelopePopup>
    </>
  );
}
