import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import { useForm, Form } from "../../controls/useForm";
import axios from "axios";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  makeStyles,
  Typography,
} from "@material-ui/core";
import { baseUrl } from "../../controls/axios";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  dialogWrapper: {
    padding: theme.spacing(2),
    position: "absolute",
    top: theme.spacing(5),
    bottom: theme.spacing(3),
    borderRadius: "30px",
    width: "90vh",
    height: "45vh",
  },
  dialogTitle: {
    paddingRight: "0px",
  },
}));

export default function Notebook({ open, handleClose, title }) {
  const data = {
    fileName: "",
    workspaceId: '172'
  };

  const classes = useStyles();
  const [values, setValues] = useState(data);
  const [openPopup, setOpenPopup] = useState(false);
  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });
  const [msg, setMsg] = useState("");

  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    title: "",
    subTitle: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
      values: data,
    });
  };
  let history = useHistory();

  const handleSubmit = (e) => {
    setMsg("");
    e.preventDefault();
    // localStorage.setItem('tab', JSON.stringify({ title: `${values.fileName}`, key: '2' }) )

    baseUrl
      .post("/notebook/notebook", values ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
      .then((response) => {
        handleClose()
        let tabarray = JSON.parse(localStorage.getItem("tab"));
        if (tabarray[0].title == "") {
          tabarray = tabarray.slice(1)
        }
        // tabarray.push({ title: `${values.fileName}`, key:`${response.data.data[0].sqlId}`})   
        tabarray.push({ title: `${values.fileName}`, key: `${Math.floor(Math.random() * (200 - 100 + 1) + 100)}` })
        localStorage.setItem("tab", JSON.stringify(tabarray))
        history.push("/develope");
      })
      .catch((error) => {
        setMsg("*Provide Unique Name");
      });
  };

  return (
    <>

      <Form onSubmit={handleSubmit}>
        <div className="form-group row">
          <label
            htmlFor="fileName"
            className="col-sm-5 col-form-label sqlLable"
          >
            Name of Notebook
          </label>
          <div className="col-sm-10">
            <p className="text-danger ml-3 small">
              {msg}</p>
            <input
              type="text"
              pattern="[^' ']+"
                title="No space allowed"
              name="fileName"
              className="form-control sqlinput"
              placeholder="Enter name of Notebook"
              defaultValue=""
              value={values.fileName}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>
        <div>
          <button

            type="submit"
            className="btn btn-primary linkbtn"
          >
            Ok
          </button>
        </div>
      </Form>

    </>
  );
}