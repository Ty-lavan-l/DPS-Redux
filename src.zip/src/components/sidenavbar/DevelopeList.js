import React, { useState, useEffect } from "react";
import "antd/dist/antd.css";
import { Layout, Menu, Breadcrumb } from "antd";
import {
  UserOutlined,
  LaptopOutlined,
  NotificationOutlined,
} from "@ant-design/icons";
import axios from "axios";
import EditIcon from "@material-ui/icons/Edit";
import ShareIcon from "@material-ui/icons/Share";
import { AlertTitle } from "@material-ui/lab";
import { Delete } from "@material-ui/icons";
import { useHistory } from "react-router-dom";
import Share from "../develope/resources/Share";
import PopupView from "../controls/PopupView";
import { baseUrl } from "../controls/axios";

const { SubMenu } = Menu;
const { Header, Content, Footer, Sider } = Layout;

function DevelopeList({ handleClose }) {
  let history = useHistory();
  const [develope, setDevelope] = useState({
    workspaceName: "employee workspace",
    workspaceDescription: "employee details",
    userId: 102,
    sqlScript: [],
    notebook: [],
    sparkjob: [],
    biAnalytic: [],
  });
  const [reload, setReload] = useState(false);
  const [openPopups, setOpenpopups] = useState(false);

  const openInPopups = () => {
    setOpenpopups(true);
  };
  useEffect(() => {
    getAllDevelope();
  }, [reload, localStorage.getItem("workspaceId")]);
  function deleteNotebook(notebookId) {
    baseUrl.get(`/notebook1/${notebookId}` ,{
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        
        "Access-Control-Allow-Origin": "*",
      }
    }).then((res) => {
      console.log(res);
      setReload(!reload);
    }).catch((err)=>{
      console.log(err);
    });
  }
  function deleteDevelop(sqlId) {
    baseUrl.get(`/sqlscript/${sqlId}` ,{
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        
        "Access-Control-Allow-Origin": "*",
      }
    }).then((res) => {
      console.log(res);
      setReload(!reload);
    }).catch((err)=>{
      console.log(err);
    });
  }

  function editDevelop(developList) {
    handleClose();
    let tabArray = JSON.parse(localStorage.getItem("tab"));
    let tab = { title: developList.fileName, key: `${developList.sqlId}` };
    if (tabArray[0].title === "") {
      tabArray = tabArray.slice(1, 1);
    }
    if (
      tabArray.findIndex((index) => index.title === developList.fileName) === -1
    ) {
      tabArray.push(tab);
    }
    localStorage.setItem("tab", JSON.stringify(tabArray));
    localStorage.setItem("hello", Math.floor(Math.random() * 99));
    history.push("/develope");
    // var current_URL = window.location.href + "";
    // if (current_URL.includes("develope")) {
    // } else {
    //   history.push("/develope");
    // }
  }
  function getAllDevelope() {
    let workspaceById = localStorage.getItem("workspaceId");
    baseUrl
      .get(`/workspace/${workspaceById}` ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      }
)

      .then((res) => {
        console.log(res.data.data[0]);
        const obj = res.data.data[0];
        console.log(obj);
        setDevelope(obj);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  console.log(develope.notebook[0]);

  return (
    <>
      <Layout>
        <Sider
          className="site-layout-background"
          width={"100%"}
          style={{ minHeight: "45vh", overflowX: "scroll" }}
        >
          <Menu
            mode="inline"
            defaultSelectedKeys={["1"]}
            defaultOpenKeys={["sub1"]}
            style={{ height: "100%" }}
          >
            <SubMenu key="sub1" icon={<UserOutlined />} title="SQL Scripts">
              {develope.sqlScript.map((fbb) => (
                <Menu.Item key={fbb.sqlId}>
                  {fbb.fileName}
                  <div className="float-right">
                    <EditIcon
                      onClick={() => editDevelop(fbb)}
                      fontsize="small"
                    />
                    {"  "}
                    <Delete
                      className="ml-3"
                      onClick={() => deleteDevelop(fbb.sqlId)}
                      fontsize="small"
                    />
                    <ShareIcon
                      className="ml-3"
                      onClick={() => openInPopups()}
                      fontsize="small"
                      fontsize="small"
                    />
                  </div>
                </Menu.Item>
              ))}
            </SubMenu>
            <SubMenu key="sub2" icon={<LaptopOutlined />} title="Notebooks">
              {develope.notebook.map((fbb) => (
                <Menu.Item key={fbb.notebookId}>
                  {fbb.fileName}{" "}
                  <div className="float-right">
                    <EditIcon
                      onClick={() => editDevelop(fbb)}
                      fontsize="small"
                    />
                    {"  "}
                    <Delete
                      className="ml-3 mr-3"
                      onClick={() => deleteNotebook(fbb.notebookId)}
                      fontsize="small"
                    />
                  </div>
                </Menu.Item>
              ))}
            </SubMenu>
            {/* <SubMenu
              key="sub3"
              icon={<NotificationOutlined />}
              title="Spark job definitions"
            >
              {develope.sparkjob.map((fbb) => (
                <Menu.Item key={fbb.sparkjobId}>{fbb.fileName}</Menu.Item>
              ))}
            </SubMenu> */}
            {/* <SubMenu
              key="sub4"
              icon={<NotificationOutlined />}
              title="Power BI"
            >
              {develope.biAnalytic.map((fbb) => (
                <Menu.Item key={fbb.bianalyticId}>{fbb.fileName}</Menu.Item>
              ))}
            </SubMenu> */}
          </Menu>
        </Sider>
      </Layout>
      <PopupView
        title="Share"
        openPopups={openPopups}
        setOpenPopups={setOpenpopups}
      >
        <Share />
      </PopupView>
    </>
  );
}

export default DevelopeList;
