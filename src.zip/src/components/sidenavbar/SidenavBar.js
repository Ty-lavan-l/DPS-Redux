import React, { useState, useEffect } from "react";
import {
  ProSidebar,
  Menu,
  MenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarContent,
} from "react-pro-sidebar";
import NavigateNextIcon from "@material-ui/icons/NavigateNext";
import NavigateBeforeIcon from "@material-ui/icons/NavigateBefore";
import DevelopeList from "./DevelopeList";
import { FiLogOut } from "react-icons/fi";
import { BsHouseDoorFill, BsServer, BsFileEarmarkText } from "react-icons/bs";
import { FaStaylinked } from "react-icons/fa";
import "react-pro-sidebar/dist/css/styles.css";
import Modal from "./Modal";
import { Dropdown } from "react-bootstrap";
import Mysql from "../formmodule/dataModule/Mysql";
import Popup from "../controls/Popup";
import MicrosoftSql from "../formmodule/dataModule/MicrosoftSqlServer";
import AwsRedShift from "../formmodule/dataModule/AwsRedShift";
import SnowFlake from "../formmodule/dataModule/SnowFlake";
import SqlScript from "../formmodule/developeModule/SqlScript";
import Notebook from "../formmodule/developeModule/Notebook";
import BiAnalytic from "../formmodule/developeModule/BiAnalytic";
import SparkJob from "../formmodule/developeModule/SparkJob";
import { useHistory } from "react-router-dom";
import DataTable from "../develope/resources/DataTable";
import FlatFile from "../formmodule/dataModule/flatfile/FlatFile";
import Popupdev from "../controls/Popupdev";
import Notification from "../controls/Notification";
import { baseUrl } from "../controls/axios";
const SidenavBar = ({ event, Dashboardcallback }) => {
  const [menuCollapse, setMenuCollapse] = useState(true);
  const [open, setOpen] = useState(false);
  const [open1, setOpen1] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [open3, setOpen3] = useState(false);
  const [sqlScript, setSqlScript] = useState(false);
  const [notebook, setNotebook] = useState(false);
  const [biAnalytic, setBiAnalytic] = useState(false);
  const [sparkJob, setSparkJob] = useState(false);
  const [flatFile, setFlatfile] = useState(false);

  let history = useHistory();

  async function logout() {
    localStorage.clear();

    window.location.reload();
  }

  useEffect(() => {
    if (event == "datamodule") {
      setmodal(true);
      setHomeIcon(false);
      setDataIcon(true);
      setDevelopIcon(false);
      setIntegrationIcon(false);
    } else if (event == "developmodule") {
      setmodaldev(true);
      setHomeIcon(false);
      setDataIcon(false);
      setDevelopIcon(true);
      setIntegrationIcon(false);
    }
  }, [event]);
  //create a custom function that will change menucollapse state from false to true and true to false
  const menuIconClick = () => {
    //condition checking to change state from true to false and vice versa
    menuCollapse ? setMenuCollapse(false) : setMenuCollapse(true);
  };
  let userId = localStorage.getItem("userId");
  const [modal, setmodal] = useState(false);
  const [modaldev, setmodaldev] = useState(false);
  const [records, setRecords] = useState([
    {
      accountNo: "",
      datasourceId: 0,
      datasourceName: "hello",
      dbTable: "",
      password: "",
      port: "",
      url: "",
      userId: 0,
      userName: "",
    },
  ]);
  console.log("this is records", records);

  const [sorted, setSorted] = useState([]);
  const [reload, setReload] = useState(false);
  const [homeIcon, setHomeIcon] = useState(false);
  const [dataIcon, setDataIcon] = useState(false);
  const [developIcon, setDevelopIcon] = useState(false);
  const [integrationIcon, setIntegrationIcon] = useState(false);
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClickOpen1 = () => {
    setOpen1(true);
  };
  const handleClickOpen2 = () => {
    setOpen2(true);
  };
  const handleClickOpen3 = () => {
    setOpen3(true);
  };
  const handleClickOpen5 = () => {
    setSqlScript(true);
  };
  const handleClickOpen6 = () => {
    setNotebook(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const microsoftSqlClose = () => {
    setOpen1(false);
  };
  const SnowFlakeClose = () => {
    setOpen2(false);
  };
  const AwsRedShiftClose = () => {
    setOpen3(false);
  };

  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });
  const [develope, setDevelope] = useState([]);
  // console.log("this is develope", develope);
  const res = develope.filter((word) => word.length < 11);
  const finalres = res.filter((word) => word.length > 7);

  useEffect(() => {
    getAll();
    var current_URL = window.location.href + "";
    if (current_URL.includes("develope") || current_URL.includes("flatfile")) {
      setDevelopIcon(true);
    } else {
      setHomeIcon(true);
    }
  }, [reload]);

  function getAll() {
    var token = localStorage.getItem("token");
    baseUrl
      .get(
        `/user/${userId}`
        // , {
        //   headers: {
        //     Authorization: `Bearer ${token}`,
        //     'Access-Control-Allow-Origin':'*'
        //   }
        // }
      )
      .then((res) => {
        setRecords(res.data.data[0]);
        setSorted(res.data.data[0].datasource);
        console.log("i m soted" + sorted.datasourceName);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  let addDevelop;
  if (
    localStorage.getItem("workspaceId") != 0
      ? (addDevelop = (
          <>
            {" "}
            <Dropdown.Menu>
              <Dropdown.Item onClick={handleClickOpen5}>
                {" "}
                Sql script{" "}
              </Dropdown.Item>
              <Dropdown.Item onClick={handleClickOpen6}>
                {" "}
                Notebook{" "}
              </Dropdown.Item>
              {/* impoetant */}
              {/* <Dropdown.Item
    onClick={() => {
      setBiAnalytic(true);
    }}
  >
    {" "}
    Bi Analytic Tool{" "}
  </Dropdown.Item>
  <Dropdown.Item onClick={handleClickOpen7}>
    {" "}
    Spark job{" "}
  </Dropdown.Item> */}
            </Dropdown.Menu>
          </>
        ))
      : (addDevelop = (
          <>
            {" "}
            <Dropdown.Menu>
              <Dropdown.Item
                onClick={() => {
                  setmodaldev(false);
                  setHomeIcon(true);
                  setDataIcon(false);
                  setDevelopIcon(false);
                  setIntegrationIcon(false);
                }}
              >
                {" "}
                Create Workspace{" "}
              </Dropdown.Item>
              <Dropdown.Item
                onClick={() => {
                  setmodaldev(false);
                  setHomeIcon(true);
                  setDataIcon(false);
                  setDevelopIcon(false);
                  setIntegrationIcon(false);
                }}
              >
                {" "}
                Choose Workspace{" "}
              </Dropdown.Item>{" "}
            </Dropdown.Menu>
          </>
        ))
  );

  const callback = (values) => {
    console.log("callback called", values);
    setReload(!reload);
    setOpen(false);
    setOpen1(false);
    setOpen2(false);
    setOpen3(false);
  };

  const developCallbackScript = () => {
    setmodaldev(false);
    setSqlScript(false);
  };
  const developCallbackNotebook = () => {
    setmodaldev(false);
    setNotebook(false);
  };
  const scriptCloseCallback = () => {
    setmodaldev(false);
  };

  return (
    <>
      <Modal show={modal}>
        <div className="card col-md-3 " id="modal_dataSource">
          <span>
            <span className="font-weight-blod header_dataSource">
              Data Sources
            </span>

            <span>
              <Dropdown id="dash_dropDown">
                <Dropdown.Toggle
                  className="btn  "
                  cssclass="e-caret-hide"
                  id="dropdown_Toggle"
                >
                  <i className="fas fa-plus addbtn"></i>
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item onClick={handleClickOpen}>
                    {/* <Mysql /> */} MySql{" "}
                  </Dropdown.Item>

                  <Dropdown.Item onClick={handleClickOpen1}>
                    {" "}
                    Microsoft SqlServer{" "}
                  </Dropdown.Item>

                  <Dropdown.Item onClick={handleClickOpen2}>
                    {" "}
                    SnowFlake{" "}
                  </Dropdown.Item>

                  <Dropdown.Item onClick={handleClickOpen3}>
                    {" "}
                    AWS Red Shift{" "}
                  </Dropdown.Item>

                  <Dropdown.Item
                    onClick={() => {
                      if (localStorage.getItem("workspaceId") != 0) {
                        setFlatfile(true);
                      } else {
                        setNotify({
                          isOpen: true,
                          message: `Create/Choose Workspace`,
                          type: "error",
                        });
                      }
                    }}
                  >
                    {" "}
                    File{" "}
                  </Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </span>
            <i
              onClick={() => {
                setmodal(false);
                setDataIcon(false);
                setIntegrationIcon(false);
                var current_URL = window.location.href + "";
                if (
                  current_URL.includes("develope") ||
                  current_URL.includes("flatfile")
                ) {
                  setDevelopIcon(true);
                  setHomeIcon(false);
                  setDataIcon(false);
                } else {
                  Dashboardcallback();
                  setHomeIcon(true);
                  setDevelopIcon(false);
                  setDataIcon(false);
                }
              }}
              className="fas fa-times-circle ml-3"
            ></i>
          </span>
          <div className="">
            <div className="input-group "></div>
          </div>
          <div>
            <b>Available Datasources :</b>
            {/* {spinner} */}
            <DataTable data={records} reloading={reload} />
          </div>
        </div>
      </Modal>
      <Modal show={modaldev}>
        <div className="card col-md-3 " id="modal_dataSource">
          <span>
            <span className="font-weight-blod header_dataSource">Develope</span>
            <span>
              <Dropdown id="dash_dropDown">
                <Dropdown.Toggle
                  className="btn  "
                  cssclass="e-caret-hide"
                  id="dropdown_Toggle"
                >
                  <i className="fas fa-plus addbtn"></i>
                </Dropdown.Toggle>

                {addDevelop}
              </Dropdown>
            </span>
            <i
              onClick={() => {
                var current_URL = window.location.href + "";
                if (
                  current_URL.includes("develope") ||
                  current_URL.includes("flatfile")
                ) {
                  setmodaldev(false);
                  setHomeIcon(false);
                  setDataIcon(false);
                  setDevelopIcon(true);
                  setIntegrationIcon(false);
                } else {
                  Dashboardcallback();
                  setmodaldev(false);
                  setHomeIcon(true);
                  setDataIcon(false);
                  setDevelopIcon(false);
                  setIntegrationIcon(false);
                }
              }}
              className="fas fa-times-circle ml-3"
            ></i>
          </span>
          <div style={{ height: "90%", overflowX: "hidden" }}>
            <div className="mt-6">
              <div className="input-group mb-3">
                {/* important */}
                {/* <input
                  style={{ height: "50px" }}
                  type="text"
                  className="form-control"
                  placeholder="filter resources by name"
                  aria-label="Reference"
                  aria-describedby="basic-addon2"
                /> */}
              </div>
            </div>
            <div>
              <DevelopeList handleClose={scriptCloseCallback} />
            </div>
          </div>
        </div>
      </Modal>

      <div id="header">
        {/* collapsed props to change menu size using menucollapse state */}
        <ProSidebar collapsed={menuCollapse}>
          <SidebarHeader className="transition">
            <div className="logotext">
              {/* small and big change using menucollapse state */}
              <p>{menuCollapse ? "DPS" : "DPS"}</p>
            </div>
            <div className="closemenu" onClick={menuIconClick}>
              {/* changing menu collapse icon on click */}
              <button className="btn">
                <i class="fas fa-bars"></i>
              </button>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <Menu iconShape="square">
              <MenuItem
                active={homeIcon}
                onClick={() => {
                  setHomeIcon(true);
                  setDataIcon(false);
                  setDevelopIcon(false);
                  setIntegrationIcon(false);
                  localStorage.setItem(
                    "tab",
                    JSON.stringify([{ title: "", key: "" }])
                  );
                  localStorage.setItem("key", 0);
                  localStorage.setItem("size", 1);
                  history.push("/");
                }}
                icon={
                  <i class="fas fa-home"/>
                }
                
              >
                Home
              </MenuItem>
              <MenuItem
                active={dataIcon}
                onClick={() => {
                  setmodal(true);
                  setHomeIcon(false);
                  setDataIcon(true);
                  setDevelopIcon(false);
                  setIntegrationIcon(false);
                }}
                icon={<i class="fas fa-database"/>}
              >
                Data
              </MenuItem>
              <MenuItem
                active={developIcon}
                onClick={() => {
                  setmodaldev(true);
                  setHomeIcon(false);
                  setDataIcon(false);
                  setDevelopIcon(true);
                  setIntegrationIcon(false);
                }}
                icon={<i class="far fa-file-alt"/>}
              >
                Develope
              </MenuItem>

              {/* <MenuItem icon={<BsFillDisplayFill />}>Monitor</MenuItem> */}
              <MenuItem
                active={integrationIcon}
                onClick={() => {
                  setHomeIcon(false);
                  setDataIcon(false);
                  setDevelopIcon(false);
                  setIntegrationIcon(true);
                }}
                icon={<FaStaylinked />}
              >
                Integration
              </MenuItem>
              {/*  <MenuItem icon={<BsFillGearFill />}>Settings</MenuItem> */}
            </Menu>
          </SidebarContent>
          <SidebarFooter>
            <Menu iconShape="square">
              <MenuItem icon={<FiLogOut />} onClick={logout}>
                Logout
              </MenuItem>
            </Menu>
          </SidebarFooter>
        </ProSidebar>

        {/* <Popup title="My SQL" openPopup={openPopup} setOpenPopup={setOpenPopup}> */}
        <Mysql
          open={open}
          handleClose={handleClose}
          ParentCallback={callback}
        />
        {/* </Popup> */}
        <Notification notify={notify} setNotify={setNotify} />
        <Popupdev openPopup={flatFile} setOpenPopup={setFlatfile}>
          <FlatFile />
        </Popupdev>
        <MicrosoftSql
          open={open1}
          handleClose={microsoftSqlClose}
          ParentCallback={callback}
        />

        <AwsRedShift
          open={open3}
          handleClose={AwsRedShiftClose}
          ParentCallback={callback}
        />

        <SnowFlake
          open={open2}
          handleClose={SnowFlakeClose}
          ParentCallback={callback}
        />

        {/* <SqlScript open={sqlScript} handleClose={handleClose5} /> */}
        <Popupdev openPopup={sqlScript} setOpenPopup={setSqlScript}>
          <SqlScript handleClose={developCallbackScript} />
        </Popupdev>
        {/* <Notebook open={notebook} handleClose={handleClose6} /> */}
        <Popupdev openPopup={notebook} setOpenPopup={setNotebook}>
          <Notebook handleClose={developCallbackNotebook} />
        </Popupdev>
        <Popup openPopup={biAnalytic} setOpenPopup={setBiAnalytic}>
          <BiAnalytic />
        </Popup>
        <Popup openPopup={sparkJob} setOpenPopup={setSparkJob}>
          <SparkJob />
        </Popup>
        {/* <SparkJob open={sparkJob} handleClose={handleClose7} /> */}
      </div>
    </>
  );
};

export default SidenavBar;
