import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div>
      <nav className="navbar">
        <p className="navbar-brand">Data Processing Software Application</p>

        <li className="logoutlink">
          <ul>

            <br />
            <Link to="/login">
              <span id="logout_button"> Logout</span>
            </Link>
          </ul>
        </li>
      </nav>
    </div>
  );
}
