import axios from "axios";
import React, { useState, useEffect } from "react";
import { Line } from "react-chartjs-2";
import Select from "react-select";
import Grid from "@material-ui/core/Grid";

const DynamicChart = () => {
  const [chartData, setChartData] = useState({});
  const [headers, setHeaders] = useState([]);
  const [xaxis, setXaxis] = useState([{}]);
  const [yaxis, setYaxis] = useState([{}]);

  let empSal = [];
  let empAge = [];


  const Chart = () => {
    let headers = [];
    var item = JSON.parse(localStorage.getItem("Json"));
    headers = Object.keys(item[0]);
    let x = xaxis.value;

    let y = yaxis.value;

    for (const dataObj of item) {
      empSal.push(dataObj[x]);
      empAge.push(dataObj[y]);
    }

    setHeaders(headers);

    setChartData({
      labels: empSal,
      datasets: [
        {
          label: "level of thicceness",
          data: empAge,
          backgroundColor: [
            "rgba(255, 99, 132, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgba(255, 206, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
            "rgba(255, 99, 132, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgba(255, 206, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
            "rgba(255, 99, 132, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgba(255, 206, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
            "rgba(255, 99, 132, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgba(255, 206, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
          ],
          borderColor: [
            "rgba(255, 99, 132, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
            "rgba(255, 159, 64, 1)",
            "rgba(255, 99, 132, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
            "rgba(255, 159, 64, 1)",
            "rgba(255, 99, 132, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
            "rgba(255, 159, 64, 1)",
            "rgba(255, 99, 132, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
            "rgba(153, 102, 255, 1)",
            "rgba(255, 159, 64, 1)",
          ],
          borderWidth: 1,
        },
      ],
    });
  };

  useEffect(() => {
    Chart();
  }, [xaxis, yaxis]);

  let options = headers.map(function (coach, i) {
    return { value: coach, label: coach };
  });

  let yoptions = headers.map(function (coach, i) {
    return { value: coach, label: coach };
  });

  const handleChange = (selectedOptions) => {
    setXaxis(selectedOptions);
  };

  const handleChangey = (selectedOptions) => {
    setYaxis(selectedOptions);
  };

  return (
    <div style={{ width: "160vh", overflow: "scroll" }}>
      <Grid container spacing={3}>
        <Grid item xs={3} style={{ textAlign: "right" }}>
          <b> X-axis : </b>
        </Grid>
        <Grid item xs={3}>
          <Select options={options} onChange={handleChange} />
        </Grid>
        <Grid item xs={1} style={{ textAlign: "right" }}>
          <b> Y-axis : </b>
        </Grid>
        <Grid item xs={3}>
          <Select options={yoptions} onChange={handleChangey} />{" "}
        </Grid>
      </Grid>

      <div>
        <Line
          data={chartData}
          options={{
            responsive: true,
            title: { text: "THICCNESS SCALE", display: true },
            scales: {
              yAxes: {
                ticks: {
                  beginAtZero: false,
                },
              },
            },
          }}
        />
      </div>
    </div>
  );
};

export default DynamicChart;
