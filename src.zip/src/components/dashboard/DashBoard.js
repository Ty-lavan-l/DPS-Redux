import { useState, useEffect } from "react";
import SidenavBar from "../sidenavbar/SidenavBar";
import Notification from "../controls/Notification";
import ConfirmDialog from "../controls/ConfirmDialog";
import Modal from "../sidenavbar/Modal";
import { Spin } from "antd";
import Select from "react-select";
import { addWorkspace, getAllWorkspace } from "../../redux/actions/getAllUser-Action";
import { useSelector, useDispatch } from 'react-redux';
import { dashboardActions } from "../../redux/reducers/dashboardReducers";

const SELECT_VALUE_KEY = "MySelectValue";

function DashBoard() {
  const modal = useSelector((state) => state.dashboard.modal);
  const spin = useSelector((state) => state.dashboard.loader);
  const records = useSelector((state) => state.dashboard.records);
  const message = useSelector((state) => state.dashboard.message);
  const dependency = useSelector((state) => state.dashboard.dependency);

  const [selected, setSelected] = useState([]);
  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });
  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    title: "",
    subTitle: "",
  });
  let userId = localStorage.getItem("userId");
  const data = {
    userId: `${userId}`,
    workspaceName: "",
    workspaceDescription: "",
  };
  const [event, setEvent] = useState(false);
  const [values, setValues] = useState(data);


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setValues({
      ...values,
      [name]: value,
      values: data,
    });
    console.log("this is values", values);
  };

  useEffect(() => {
    getAll();
  }, [dependency]);

  useEffect(() => {
    const lastSelected = JSON.parse(
      localStorage.getItem(SELECT_VALUE_KEY) ?? "[]"
    );
    setSelected(lastSelected);
  }, []);

  const dispatch = useDispatch();

  const getAll = () => {
    dispatch(getAllWorkspace(userId));
  }
  console.log(records);

  const name = localStorage.getItem('username')
  console.log("this is username", name)

  const handleSubmit = (e) => {
    e.preventDefault();
    dispatch(addWorkspace(values, data));
  }

  let spinner;
  if (
    spin == true
      ? (spinner = <Spin style={{ marginLeft: "39vh" }} />)
      : (spinner = <></>)
  );
  const callback = () => {
    setEvent("");
  };
  let option;
  option = records.map(function (records, i) {
    return { value: records.workspaceId, label: records.workspaceName };
  });

  const readWorkspaceId = (selectedOptions) => {
    localStorage.setItem(SELECT_VALUE_KEY, JSON.stringify(selectedOptions));
    setSelected(selectedOptions);
    console.log(selectedOptions);
    localStorage.setItem("workspaceId", selectedOptions.value);
  };
  return (
    <div style={{ display: "flex" }}>
      <SidenavBar event={event} Dashboardcallback={callback} />

      <Modal show={modal}>
        <div className="card col-sm-6 " id="modal">
          <div className="card-body">
            <h5 className="h5">Create New Workspace</h5>
            <form onSubmit={handleSubmit}>
              <div className="form-group offset-1">
                <label htmlFor="workspaceName">Enter The Workspace Name</label>
                <input
                  type="text"
                  pattern="[^' ']+"
                  title="No empty space allowed"
                  name="workspaceName"
                  value={values.workspaceName}
                  onChange={handleInputChange}
                  className="form-control"
                  id="project-name"
                  required
                />
              </div>
              <div className="form-group offset-1">
                <label htmlFor="workspaceDescription">
                  Enter the Workspace Description
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="description"
                  name="workspaceDescription"
                  value={values.workspaceDescription}
                  onChange={handleInputChange}
                  required
                />
              </div>

              <span>
                <button
                  type="submit"
                  className="btn btn-primary button"
                >
                  Create
                </button>

                <button
                  type="button"
                  className="btn btn-primary offset-1 button"
                  onClick={() => {
                    dispatch(dashboardActions.createWorkspace({modal : false}))
                    dispatch(dashboardActions.createWorkspace({data : data}))
                  }}
                >
                  Close
                </button>
              </span>
            </form>
          </div>
        </div>
      </Modal>
      <div>
        <Notification notify={notify} setNotify={setNotify} />
        <ConfirmDialog
          confirmDialog={confirmDialog}
          setConfirmDialog={setConfirmDialog}
        />
      </div>

      <div className="background  ">
        <div>
          <nav className="navbar">
            <h1 className="navbar-brand">
              Data Processing Software Application
            </h1>
            <h5 className="text-capitalize">Welcome {name}</h5>
          </nav>
        </div>
        <div className="col-md-4 cards ">
          <h3 className="h3 ">Create Or Choose A Workspace</h3>
          <span>
            <button
              className="btn mt-3 col-md-3"
              id="newbtn"
              onClick={() => {
                dispatch(dashboardActions.createWorkspace({modal : true}))
              }}
            >
              New
            </button>
            <Select
              className="btn mt-3 col-md-6 select text-left text-capitalize"
              value={selected}
              options={option}
              onChange={readWorkspaceId}
            />
          </span>
        </div>

        <div className=" cards mr-5 mt-5  pb-5 ">
          <div className="row">
            <div
              className="col-md-3 "
              onClick={(e) => {
                setEvent("datamodule");
              }}
            >
              <div className="card p-1  shadow">
                <div className="row m-0">
                  <div className="col-md-4 p-3 ">
                    <img
                      alt="Data Inject"
                      id="image_datainject"
                      src="https://icon-library.com/images/data-ingestion-icon/data-ingestion-icon-25.jpg"
                      className="imgFluid cardimage"
                    />
                  </div>
                  <div className="col-md-8 " style={{ height: "128px" }}>
                     <div className=" cardTitle font-weight-bold ">
                      Data Inject
                    </div>
                      Use The Data Tool To Import Data From Different Datasource
                      via DPS
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3" onClick={() => setEvent("developmodule")}>
              <div className="card p-1 shadow">
                <div className="row m-0">
                  <div className="col-md-4 p-2">
                    <img
                      alt=" Data Explore"
                      src="https://cdn3.iconfinder.com/data/icons/databases-3/512/search_data-512.png"
                      className="imgFluid cardimage"
                    />
                  </div>

                  <div className="col-md-8 p-2 " style={{ height: "125px" }}>
                    <div className=" cardTitle font-weight-bold head_DS_card">
                      Data Explore
                    </div>
                   
                      Learn How To Navigate And Interact With Your Data
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3" onClick={() => setEvent("developmodule")}>
              <div className="card shadow ">
                <div className="row m-0">
                  <div className="col-md-4 p-3  justify-content-center align-items-center">
                    <img
                      alt="Data Analyze"
                      src="https://www.itrsgroup.com/sites/default/files/styles/paragraph_media/public/2020-06/market-data-monitoring-icon.png?itok=jyioTxtb"
                      className="imgFluid cardimage"
                    />
                  </div>
                  <div className="col-md-8 p-2 " style={{ height: "133px" }}>
                    <div className="cardTitle font-weight-bold ">
                      Data Analyze
                    </div>
                 
                      Learn How To Use SQL Or Spark To Get Insights From Your
                      Data
                  </div>
                </div>
              </div>
            </div>
            <div
              className="col-md-3"
              onClick={() =>
                setNotify({
                  isOpen: true,
                  message: `BI is under process`,
                  type: "error",
                })
              }
            >
              <div className="card  shadow">
                <div className="row m-0">
                  <div className="col-md-4 p-3  ">
                    <img
                      alt=" Data Visualize"
                      src="https://ubiq.co/static/images/marketing/tour/advanced_charts.png"
                      className="imgFluid cardimage"
                    />
                  </div>
                  <div className="col-md-8 p-2" style={{ height: "133px" }}>
                    <div className=" cardTitle font-weight-bold head_DS_card ">
                      Data Visualize
                    </div>
                    <div
                      class="card card-block h-100"
                      className=" cardSUbtitle "
                    >
                      Build Data Interaction With Multiple BI Tools.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-12 secondHalf">
          <div className="row">
            <div className="col-md-5 cards  ">
              <h5 className="font-weight-bold mt-3  f1">Recent Workspace's</h5>

              <div className="row d-flex " id="head_workSpace">
                <div className=" col-md-6">
                  <p className="font-weight-bold mt-3  justify-content-center ml-5 ">
                    Workspace Name
                  </p>
                  <div>
                    <ul className="text-capitalize">
                      {records.map((records) => (
                        <li key={records.userId}>
                          {records.workspaceName}
                          <br />
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className="col-md-6 head_lastmodify ">
                  <p className="font-weight-bold mt-3  justify-content-center ml-5">
                    Last Modified On
                  </p>
                  <div>
                    <ul style={{ listStyle: "none" }}>
                      {records.map((records) => (
                        <li key={records.userId}>
                          {records.lastModified}
                          <br />
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                {spinner}
                <p style={{ marginLeft: "35vh" }}>{message}</p>
              </div>
            </div>
            <div className="col-md-4 ml-3 ">
              <h5 className="font-weight-bold mt-3 ">Resources & FAQ's</h5>
              <ul>
                <li> No Data Found</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DashBoard;
