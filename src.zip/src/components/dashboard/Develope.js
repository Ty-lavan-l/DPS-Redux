import Navbar from '../navbar/Navbar';
import SidenavBar from '../sidenavbar/SidenavBar';
import DevelopeDashboard from '../../components/develope/DevelopeDashboard';

function Develope() {
    return (
        <>

            <div style={{ display: 'flex' }}>
                {/* NavBar imported */}
                {/* <nav className="navbar">
                    <h1 className="navbar-brand">Data Processing Software Application</h1>
                </nav> */}
                {/* Header imported */}
                <SidenavBar />
                {/* Header imported */}

                {/* Modal for new Button */}
                <DevelopeDashboard />
            </div>
        </>
    );
}

export default Develope;
