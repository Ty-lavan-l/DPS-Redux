import Navbar from '../navbar/Navbar';
import SidenavBar from '../sidenavbar/SidenavBar';
import DataDevelope from '../../components/develope/dataDevelpoe/DataDevelope';

function FlatFileEditor() {
    return (
        <div className="d-flex"
        >
            {/* NavBar imported */}

            {/* Header imported */}
            <SidenavBar />
            {/* Header imported */}

            {/* Modal for new Button */}
            <DataDevelope />
        </div >
    );
}

export default FlatFileEditor;
