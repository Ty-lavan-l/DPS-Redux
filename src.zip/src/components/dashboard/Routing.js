import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import DashBoard from './DashBoard';
import Develope from './Develope';
import FlatFileEditor from './FlatFileEditor'
export default function Routing() {
    return (
        <Router>
            <div>
                <Switch>
                    <Route path='/develope'>
                    <Develope />
                    </Route>
                    <Route path='/flatfile'>
                    <FlatFileEditor/>
                    </Route>
                    <Route path='/'>
                        <DashBoard />
                    </Route>
                </Switch>
            </div>
        </Router>
    );
}
