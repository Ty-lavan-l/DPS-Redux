import React from 'react';
import Navbar from '../navbar/Navbar';
import './developeDashboard.css';
import EditorTab from './resources/EditorTab';
function DevelopeDashboard() {
    return (
        <div className='container-fluid '>
            <div>
                <div>
                    <Navbar />
                </div>

                <div className='quary'>

                    <EditorTab />
                </div>
               
            </div>
        </div>
    );
}

export default DevelopeDashboard;
