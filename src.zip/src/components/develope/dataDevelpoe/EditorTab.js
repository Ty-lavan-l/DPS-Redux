import React, { useState } from "react";
import "antd/dist/antd.css";
import { Tabs } from "antd";
import CodeEditor from "./Editor";
import {useHistory} from 'react-router-dom'
const { TabPane } = Tabs;
export default function EditorTab() {
  const [activeKey, setActiveKey] = useState(JSON.parse(localStorage.getItem("flatfile"))[0].key);
  const [panes, setPanes] = useState(JSON.parse(localStorage.getItem("flatfile")));
  // const [isLoggedIn, setIsLoggedIn] = useState(JSON.parse(localStorage.getItem("flatfile")) || 0);
 
  const onChange = (activeKey) => {
    
    setActiveKey( activeKey );
    localStorage.setItem("flatkey",activeKey)
  };

  const onEdit = (targetKey, action) => {
    remove(targetKey)
  };
  let history = useHistory ();
  
  const remove = (targetKey) => {
    let tabArray=JSON.parse(localStorage.getItem("flatfile")) 
   
    for(var i = 0; i < tabArray.length; i++) {
      if(tabArray[i].key == targetKey) {
          tabArray.splice(i, 1);
          if(tabArray.length==0){
            tabArray.push({"title":"","key":``})
            localStorage.setItem("flatfile",JSON.stringify(tabArray))
            localStorage.setItem("key",0)
            history.push("/");
          }
          localStorage.setItem("flatfile",JSON.stringify(tabArray))
          break;
      }
  }
    let newActiveKey = activeKey;
    let lastIndex;
    panes.forEach((pane, i) => {
      if (pane.key === targetKey) {
        lastIndex = i - 1;
      }
    });
    const newPanes = panes.filter((pane) => pane.key !== targetKey);
    if (newPanes.length && newActiveKey === targetKey) {
      if (lastIndex >= 0) {
        newActiveKey = newPanes[lastIndex].key;
      } else {
        newActiveKey = newPanes[0].key;
      }
    }
    setActiveKey(newActiveKey );
    setPanes(newPanes);
  };


  setTimeout(() => {
    setPanes(JSON.parse(localStorage.getItem("flatfile")));
    setActiveKey( localStorage.getItem("flatkey"));
  }, 5000);

    return (
      <Tabs
      hideAdd
        type="editable-card"
        onChange={(e)=>onChange(e)}
        activeKey={activeKey}
        onEdit={(e)=>onEdit(e)}
      >
        {panes.map((pane) => (
          <TabPane tab={pane.title} key={pane.key} closable={pane.closable}>
            <CodeEditor />
          </TabPane>
        ))}
      </Tabs>
    );
  
}

