import React, { useState, useEffect } from "react";
import Editor from "react-simple-code-editor";
import { highlight, languages } from "prismjs/components/prism-core";
import "prismjs/components/prism-clike";
import "prismjs/components/prism-javascript";
import "prismjs/themes/prism.css"; //Example style, you can use another
import { Button, Dropdown, Menu } from "antd";
import { DeleteOutlined, SyncOutlined } from "@ant-design/icons";
import { JsonToTable } from "react-json-to-table";
import {
  CaretRightOutlined,
  DownOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { UserConsumer } from "../../../UserContext";
import DevelopeChart from "../../charts/DevelopeChart";
import Donut from "../../charts/Develpe";
import Grid from "@material-ui/core/Grid";
import { withStyles } from "@material-ui/core/styles";
import Switch from "@material-ui/core/Switch";
import FormGroup from "@material-ui/core/FormGroup";
import Typography from "@material-ui/core/Typography";
import CsvDownload from "react-json-to-csv";
import exportFromJSON from "export-from-json";
import Linechart from "../../charts/LineChart";
import { Spin, Space } from "antd";
import Select from "react-select";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import OpenWithIcon from "@material-ui/icons/OpenWith";
import StickyHeadTable from "./DynamicTable";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Box from "@material-ui/core/Box";
import Paper from "@material-ui/core/Paper";
import PropTypes from "prop-types";
import { baseUrl, sparkUrl } from "../../controls/axios";
const dataSourceType = "";
const code = ``;
var datasourceId;
var userId = localStorage.getItem("userId");
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`nav-tabpanel-${index}`}
      aria-labelledby={`nav-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `nav-tab-${index}`,
    "aria-controls": `nav-tabpanel-${index}`,
  };
}

function LinkTab(props) {
  return (
    <Tab
      component="a"
      onClick={(event) => {
        event.preventDefault();
      }}
      {...props}
    />
  );
}

const data = '[{"foo":"foo"},{"bar":"bar"}]';

export let dataResult = [];

const fileName = "download";
const exportType = "xls";
const AntSwitch = withStyles((theme) => ({
  root: {
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
  },
  switchBase: {
    padding: 2,
    color: theme.palette.grey[500],
    "&$checked": {
      transform: "translateX(12px)",
      color: theme.palette.common.white,
      "& + $track": {
        opacity: 1,
        backgroundColor: theme.palette.primary.main,
        borderColor: theme.palette.primary.main,
      },
    },
  },
  thumb: {
    width: 12,
    height: 12,
    boxShadow: "none",
  },
  track: {
    border: `1px solid ${theme.palette.grey[500]}`,
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor: theme.palette.common.white,
  },
  checked: {},
}))(Switch);

class CodeEditor extends React.Component {
  static CodeEditor = [];

  constructor(props) {
    super(props);
    this.state = {
      code,
      dataSourceType: "",
      person: [],
      checked: false,
      chartType: "",
      spin: false,
      value: 0,
      messege: "",
      size: 40,
      query: "",
      info: false,
    };

    this.handleDropdownChange = this.handleDropdownChange.bind(this);
    this.handleChartChange = this.handleChartChange.bind(this);
  }

  //dataResult = this.state.persons;
  handleDropdownChange(e) {
    this.setState({ dataSourceType: e.target.value });
    baseUrl
      .get(`/user/${userId}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        },
      })

      .then((res) => {
        var response = res.data.data[0].datasource;

        var MySql = response.find(
          (element) => element.datasourceName === this.state.dataSourceType
        );
        // if ((element.datasourceName = dataSourceType)) {
        //   id = element.datasourceId;
        // }
        console.log(MySql);
        datasourceId = MySql.datasourceId;
        console.log(datasourceId);
      })

      .catch((err) => {
        console.log(err);
      });
  }
  handleMouseEvent = (e) => {
    this.setState({ query: window.getSelection().toString() });
    console.log("selected query");
    console.log(this.state.query);
  };

  refreshPage = () => {
    window.location.reload(false);
  };
  clearAll = (e) => {
    this.setState({ code: "" });
  };

  postAll = (e) => {
    e.preventDefault();
    this.setState({ person: [] });
    this.setState({ value: 0 });
    this.setState({ messege: "" });
    console.log("this is code ", this.state.code);
    var CONTENT = localStorage.getItem("Json");
    var QUERY = this.state.query;
    if (QUERY == "") {
      alert("select query to execute");
    } else {
      this.setState({ spin: true });
      sparkUrl
        .post(`/datasource-connection/flatfile`, {
          QUERY,
          CONTENT,
        })
        .then((res) => {
          this.setState({ query: "" });
          this.setState({ spin: false });

          if (res.data.data == null) {
            localStorage.setItem("result", JSON.stringify([{}]));
            this.setState({ messege: "ERROR" });
            this.setState({ value: 1 });
            this.setState({ spin: false });
            this.setState({ query: "" });
          } else {
            this.setState({ person: res.data.data });
            localStorage.setItem("result", JSON.stringify(this.state.person));
            this.setState({ messege: "Success" });

            this.setState({ value: 0 });
          }
          // this.setState({ messege: res.data.message });
          // if (res.data.error == true) {
          //   this.setState({ value: 1 });
          // } else {
          //   this.setState({ value: 0 });
          // }
        })
        .catch((err) => {
          this.setState({ messege: "ERROR" });
          this.setState({ value: 1 });
          this.setState({ spin: false });
          this.setState({ query: "" });
        });
    }
  };

  refreshPage = () => {
    window.location.reload(false);
  };
  clearAll = (e) => {
    this.setState({ code: "" });
  };
  handleChange = () => {
    console.log(this.state.checked);
    if (this.state.checked) {
      this.setState({ checked: false });
    } else {
      this.setState({ checked: true });
    }
  };
  handleChangeTab = (event, newValue) => {
    this.setState({ value: newValue });
  };

  ExportToExcel = () => {
    var a = data;
    exportFromJSON({ a, fileName, exportType });
  };

  handleChartChange(e) {
    this.setState({ chartType: e.value });
    console.log(e.value);
  }
  componentDidMount() {
    this.setState({ person: JSON.parse(localStorage.getItem("Json")) });
  }
  render() {
    const typeOfChart = [
      {
        value: "Select",
        label: "Bar Chart",
      },
      {
        value: "linechart",
        label: "Line Chart",
      },
      {
        value: "piechart",
        label: "Pie Chart",
      },
    ];

    const checked = this.state.checked;
    let AuthButton;

    if (this.state.chartType === "piechart") {
      AuthButton = <Donut />;
    } else if (this.state.chartType === "linechart") {
      AuthButton = <Linechart />;
    } else {
      AuthButton = <DevelopeChart />;
    }
    let spinner;
    let sizer;
    if (
      this.state.spin
        ? (spinner = <Spin style={{ marginLeft: "90vh" }} />)
        : (spinner = (
            <>
              <StickyHeadTable />
            </>
          ))
    )
      if (this.state.size === 40) {
        sizer = (
          <OpenWithIcon
            onClick={() => {
              if (this.state.size === 40) {
                this.setState({ size: 1 });
              } else {
                this.setState({ size: 40 });
              }
            }}
            style={{ marginLeft: "80%", marginTop: "10%" }}
          />
        );
      } else {
        sizer = (
          <KeyboardArrowDownIcon
            onClick={() => {
              if (this.state.size === 40) {
                this.setState({ size: 1 });
              } else {
                this.setState({ size: 40 });
              }
            }}
            style={{ marginLeft: "80%", marginTop: "10%" }}
          />
        );
      }
    let infoMsg;
    if (
      this.state.info
        ? (infoMsg = <small>"Use temporary table name as demo"</small>)
        : (infoMsg = <></>)
    )
      return (
        <>
          <Button
            onClick={this.postAll}
            variant="contained"
            icon={<CaretRightOutlined />}
          >
            Run
          </Button>
          <span>
            {" "}
            <i
              class="fas fa-info-circle"
              onMouseOver={() => this.setState({ info: !this.state.info })}
              onMouseLeave={() => this.setState({ info: !this.state.info })}
            ></i>
            {infoMsg}
          </span>
          <span style={{ float: "right" }}>
            <span style={{ marginBottom: 16, marginLeft: 10 }}>
              <Button onClick={this.clearAll}>
                <i class="far fa-trash-alt mr-1"></i> Discard all
              </Button>
            </span>
            <span style={{ marginBottom: 16, marginLeft: 10 }}>
              <Button onClick={this.refreshPage}>
                <i class="fas fa-redo-alt mr-1"></i>
                Refresh
              </Button>
            </span>
          </span>
          <div className="border border-dark">
            <Editor
              value={this.state.code}
              onValueChange={(code) => this.setState({ code })}
              onMouseUpCapture={(e) => this.handleMouseEvent(e)}
              highlight={(code) => highlight(code, languages.js)}
              padding={10}
              style={{
                fontFamily: '"Fira code", "Fira Mono", monospace',
                fontSize: 12,
                height: `${this.state.size}vh`,
              }}
            />
          </div>
          <Paper square>
            <Tabs
              value={this.state.value}
              onChange={this.handleChangeTab}
              textColor="primary"
              indicatorColor="primary"
              aria-label="nav tabs example"
            >
              <LinkTab
                label="Result"
                className="tabs"
                href="/result"
                {...a11yProps(0)}
              />
              <LinkTab
                label="Messages"
                className="tabs"
                href="/messages"
                {...a11yProps(1)}
              />
            </Tabs>
          </Paper>

          <TabPanel value={this.state.value} index={1}>
            <p className="">{this.state.messege}</p>
          </TabPanel>
          <TabPanel value={this.state.value} index={0}>
            <FormGroup style={{ marginLeft: "160vh" }}>
              <Typography component="div" style={{ marginTop: "-7vh" }}>
                <Grid
                  component="label"
                  container
                  alignItems="center"
                  spacing={1}
                >
                  <Grid item>Table</Grid>
                  <Grid item>
                    <AntSwitch
                      checked={this.state.checked}
                      onChange={this.handleChange}
                      name="checkedC"
                    />
                  </Grid>
                  <Grid item>Chart</Grid>
                </Grid>
              </Typography>
              {sizer}
            </FormGroup>
            <div>
              <span style={{ marginLeft: "95%" }}></span>
              <CsvDownload
                classname="btn-sm btn"
                data={this.state.person}
                className="btn btn-sm"
              >
                CSV
                <i className="fas fa-download" />
              </CsvDownload>
              {/* <button type="button"  onClick={this.ExportToExcel}>Download Excel <i className="fas fa-download"/></button>  */}
              <div>
                {checked ? (
                  <>
                    <span>
                      <b>Chart Type</b> :{" "}
                      <Select
                        className="btn col-md-2"
                        onChange={this.handleChartChange}
                        options={typeOfChart}
                      />
                    </span>
                    <div style={{ display: "flex", justifyContent: "center" }}>
                      {AuthButton}
                    </div>
                  </>
                ) : (
                  <>{spinner}</>
                )}
              </div>
            </div>
          </TabPanel>
        </>
      );
  }
}

export default CodeEditor;
