import React from 'react';
import Navbar from '../../navbar/Navbar';
import '../developeDashboard.css';
import EditorTab from './EditorTab';
function DataDevelope() {
    return (
        <div className="container-fluid" >
            <div >
                <Navbar />
            </div>

            <div className='quary'>
                <EditorTab />
            </div>
        </div>
    );
}

export default DataDevelope;
