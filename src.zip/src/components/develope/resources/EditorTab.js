import React, { useEffect, useState } from "react";
import "antd/dist/antd.css";
import { Tabs } from "antd";
import CodeEditor from "./Editor";
import { useHistory } from "react-router-dom";
const { TabPane } = Tabs;
export default function EditorTab() {
  const [activeKey, setActiveKey] = useState(
    JSON.parse(localStorage.getItem("tab"))[0].key
  );
  const [panes, setPanes] = useState(JSON.parse(localStorage.getItem("tab")));
  // const [isLoggedIn, setIsLoggedIn] = useState(JSON.parse(localStorage.getItem("tab")) || 0);
  const [res, setRes] = useState(false);

  const onChange = (activeKey) => {
    setActiveKey(activeKey);
    localStorage.setItem("key", activeKey);
  };

  const onEdit = (targetKey, action) => {
    remove(targetKey);
  };
  let history = useHistory();

  const remove = (targetKey) => {
    let tabArray = JSON.parse(localStorage.getItem("tab"));

    for (var i = 0; i < tabArray.length; i++) {
      if (tabArray[i].key == targetKey) {
        tabArray.splice(i, 1);
        if (tabArray.length == 0) {
          tabArray.push({ title: "", key: `` });
          localStorage.setItem("tab", JSON.stringify(tabArray));
          localStorage.setItem("key", 0);
          history.push("/");
        }
        localStorage.setItem("tab", JSON.stringify(tabArray));
        break;
      }
    }
    let newActiveKey = activeKey;
    let lastIndex;
    panes.forEach((pane, i) => {
      if (pane.key === targetKey) {
        lastIndex = i - 1;
      }
    });
    const newPanes = panes.filter((pane) => pane.key !== targetKey);
    if (newPanes.length && newActiveKey === targetKey) {
      if (lastIndex >= 0) {
        newActiveKey = newPanes[lastIndex].key;
      } else {
        newActiveKey = newPanes[0].key;
      }
    }
    setActiveKey(newActiveKey);
    setPanes(newPanes);
    localStorage.setItem("size",JSON.parse(localStorage.getItem("tab")).length);
  };

  useEffect(() => {


  },[1000]);


  setTimeout(() => {
    if (JSON.parse(localStorage.getItem("tab")).length > localStorage.getItem("size")) {

     localStorage.setItem("refresh",true);
      localStorage.setItem("size",JSON.parse(localStorage.getItem("tab")).length);
    }
    if(JSON.parse(localStorage.getItem("refresh"))){
      setTimeout(() => {
        setPanes(JSON.parse(localStorage.getItem("tab")))
        setActiveKey(JSON.parse(localStorage.getItem("tab"))[JSON.parse(localStorage.getItem("tab")).length-1].key);
        
        localStorage.setItem("refresh",false);
      }, 1000);
    }
  }, 5000);


  return (
    <Tabs
      hideAdd
      type="editable-card"
      onChange={(e) => onChange(e)}
      activeKey={activeKey}
      onEdit={(e) => onEdit(e)}
    >
      {panes.map((pane) => (
        <TabPane tab={pane.title} key={pane.key} closable={pane.closable}>
          <CodeEditor />
        </TabPane>
      ))}
    </Tabs>
  );
}
