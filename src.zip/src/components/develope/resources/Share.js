import React, { useEffect, useState } from "react";
import { useHistory } from "react-router-dom";
import axios from "axios";
import { useForm, Form } from "../../controls/useForm";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  makeStyles,
  Typography,
} from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
    },
  },
  dialogWrapper: {
    padding: theme.spacing(2),
    position: "absolute",
    top: theme.spacing(5),
    bottom: theme.spacing(3),
    borderRadius: "30px",
    width: "90vh",
    height: "45vh",
  },
  dialogTitle: {
    paddingRight: "0px",
  },
}));

export default function Share({ open, handleClose, title }) {
  const [values, setValues] = useState();
  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });

  const handleInputChange = (e) => {
      setValues(e.target.value)
  };

  const handleSubmit = (e) => {};
  return (
    <>
      <Form onSubmit={handleSubmit}>
        <div className="form-group row">
          <label
            htmlFor="fileName"
            className="col-sm-5 col-form-label sqlLable"
          >
            Please Enter EmailId
          </label>
          <div className="col-sm-10">
            <input
              type="email"
              name="email"
              className="form-control sqlinput"
              placeholder="Enter Email"
              defaultValue=""
              value={values}
              onChange={handleInputChange}
              required
            />
          </div>
        </div>
        <div>
          <button type="submit" className="btn btn-primary linkbtn">
            Ok
          </button>
        </div>
      </Form>
    </>
  );
}
