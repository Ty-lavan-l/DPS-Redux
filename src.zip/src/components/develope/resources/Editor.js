import React, { useState, useEffect } from "react";
import Editor from "react-simple-code-editor";
import { highlight, languages } from "prismjs/components/prism-core";
import "prismjs/components/prism-clike";
import "prismjs/components/prism-javascript";
import "prismjs/themes/prism.css"; //Example style, you can use another
import { Button, Spin } from "antd";
import { CaretRightOutlined } from "@ant-design/icons";
import Grid from "@material-ui/core/Grid";
import FormGroup from "@material-ui/core/FormGroup";
import Typography from "@material-ui/core/Typography";
import Switch from "@material-ui/core/Switch";
import DevelopeChart from "../../charts/DevelopeCharts/DevelopeChart";
import Donut from "../../charts/DevelopeCharts/Develpe";
import CsvDownload from "react-json-to-csv";
import { useSelector, useDispatch } from 'react-redux';
import { withStyles } from "@material-ui/core/styles";
import Linechart from "../../charts/DevelopeCharts/LineChart";
import Restapi from "../../formmodule/developeModule/Restapi";
import Select from "react-select";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Box from "@material-ui/core/Box";
import Paper from "@material-ui/core/Paper";
import PropTypes from "prop-types";
import KeyboardArrowDownIcon from "@material-ui/icons/KeyboardArrowDown";
import OpenWithIcon from "@material-ui/icons/OpenWith";
import StickyHeadTable from "./DynamicTable";
import { baseUrl, sparkUrl } from "../../controls/axios";
import Popupapi from "../../controls/Popupapi";
import { editorActions } from "../../../redux/reducers/editorReducer";
import { fileContent, getAllWorkspace } from "../../../redux/actions/editor-Actions";



const code = ``;
var datasourceId;
var userId = localStorage.getItem("userId");

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`nav-tabpanel-${index}`}
      aria-labelledby={`nav-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired,
};

function a11yProps(index) {
  return {
    id: `nav-tab-${index}`,
    "aria-controls": `nav-tabpanel-${index}`,
  };
}

function LinkTab(props) {
  return (
    <Tab
      component="a"
      onClick={(event) => {
        event.preventDefault();
      }}
      {...props}
    />
  );
}

const AntSwitch = withStyles((theme) => ({
  root: {
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
  },
  switchBase: {
    padding: 2,
    color: theme.palette.grey[500],
    "&$checked": {
      transform: "translateX(12px)",
      color: theme.palette.common.white,
      "& + $track": {
        opacity: 1,
        backgroundColor: theme.palette.primary.main,
        borderColor: theme.palette.primary.main,
      },
    },
  },
  thumb: {
    width: 12,
    height: 12,
    boxShadow: "none",
  },
  track: {
    border: `1px solid ${theme.palette.grey[500]}`,
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor: theme.palette.common.white,
  },
  checked: {},
}))(Switch);

const fileName = "download";
const exportType = "xls";

function FunctionEditor() {
    const [code, setCode] = useState('');
    const [dataSources, setDataSources] = useState([["nodata"]]);
    const [datasourceObj, setDatasourceObj] = useState( [{ datasourceName: "no datasource" }]);
    const [dataSourceType, setDataSourceType] = useState("");
    const [person, setPerson] = useState([{}]);
    const [checked, setChecked] = useState(false);
    const [spin, setSpin] = useState(false);
    const [chartType, setChartType] = useState("");
    const [value, setValue] = useState(0);
    const [messege, setMessege] = useState("");
    const [size, setSize] = useState(40);
    const [query, setQuery] = useState("");
    const [restGet, setRestGet] = useState(false);

    const handleDropdownChange = (e) => {
        setDataSourceType(e.value);
        baseUrl
        .get(`/user/${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
  
        .then((res) => {
          var response = res.data.data[0].datasource;
  
          var MySql = response.find(
            (element) => element.datasourceName === dataSourceType
          );
  
          datasourceId = MySql.datasourceId;
          console.log(datasourceId);
        })
  
        .catch((err) => {
          console.log(err);
        });
    }
    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getAllWorkspace());
  
    let tabName = JSON.parse(localStorage.getItem("tab"));
    let key = localStorage.getItem("key");
    if (key == 0) {
      var fileName = tabName[0].title;
    } else {
      let object = tabName.find((x) => x.key == key);
      var fileName = object.title;
    }
    var workspaceId = localStorage.getItem("workspaceId");

    dispatch(fileContent(fileName,workspaceId ));

   
    }, [])

    const handleChangeTab = (event, newValue) => {
        setValue(newValue)
      };


     const refreshPage = () => {
        window.location.reload(false);
      };
     const clearAll = (e) => {
        setCode("")
      };

      const  handleChartChange =(e) =>{
        setChartType(e.value);
      }

      const Publish = (e) => {
        setRestGet(true)
      };
      const close = (e) => {
        setRestGet(false)
      };

      const handleChange = () => {
        if (checked) {
          setChecked(false);
        } else {
          setChecked(true);
        }
      };
      const handleMouseEvent = (e) => {
        setQuery(window.getSelection().toString())
        console.log(query);
      };

      const postAll = (e) => {
        e.preventDefault();
        setValue(0);
        setMessege("");
        setPerson([{}]);

        var QUERY = query;
        if (QUERY == "") {
          alert("select query to execute");
        } else {
          setSpin(true)
          baseUrl
            .get(`/data-source/${datasourceId}`, {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
                contentType: "application/json",
                "Access-Control-Allow-Origin": "*",
              },
            })
            .then((res) => {
              console.log(res.data.data[0].url);
              var URL = res.data.data[0].url;
              var USERNAME = res.data.data[0].userName;
              var PASSWORD = res.data.data[0].password;
              var ACCOUNT = res.data.data[0].accountNo;
              console.log(
                "the result ",
                URL,
                USERNAME,
                PASSWORD,
                "gfhdghdh",
                res.data.data[0].datasourceType
              );
              var tabName = JSON.parse(localStorage.getItem("tab"));
              var key = localStorage.getItem("key");
              if (key == 0) {
                var fileName = tabName[0].title;
              } else {
                var object = tabName.find((x) => x.key == key);
                var fileName = object.title;
              }
              if (res.data.data[0].datasourceType == "AwsRedShift") {
                sparkUrl
                  .post(`/datasource-connection/amazon-redshift`, {
                    URL,
                    USERNAME,
                    PASSWORD,
                    QUERY,
                  })
                  .then((res) => {
                    setQuery("")
                    setSpin(false)
                    if (res.data.data == null) {
                      setPerson([{}]);
                    } else {
                      setPerson( res.data.data)
                    }
    
                    setMessege(res.data.message)
                    if (res.data.error == true) {
                      setValue(1)
                    } else {
                      setValue(0)
                    }
                  })
                  .catch((err) => {
                    setSpin(false);
                    setQuery("");
                  });
              } else if (res.data.data[0].datasourceType == "SnowFlake") {
                sparkUrl
                  .post(`/datasource-connection/snowflake`, {
                    URL,
                    USERNAME,
                    PASSWORD,
                    QUERY,
                    ACCOUNT,
                  })
                 .then((res) => {
                    setQuery("")
                    setSpin(false)
                    if (res.data.data == null) {
                      setPerson([{}]);
                    } else {
                      setPerson( res.data.data)
                    }
    
                    setMessege(res.data.message)
                    if (res.data.error == true) {
                      setValue(1)
                    } else {
                      setValue(0)
                    }
                  })
                  .catch((err) => {
                    setSpin(false);
                    setQuery("");
                  });
              } else if (res.data.data[0].datasourceType == "Mysql") {
                sparkUrl
                  .post(`/datasource-connection/mysql`, {
                    URL,
                    USERNAME,
                    PASSWORD,
                    QUERY,
                  })
                  .then((res) => {

                    setQuery("")
                    setSpin(false)
                    if (res.data.data == null) {
                      setPerson([{}]);
                    } else {
                      setPerson( res.data.data);
                      sessionStorage.setItem(
                        "result",
                        JSON.stringify(res.data.data)
                      );
                    }
                    setMessege(res.data.message)
                    if (res.data.error == true) {
                      setValue(1)
                    } else {
                      setValue(0)
                    }
                  })
                  .catch((err) => {
                    setSpin(false);
                    setQuery("");
                  });
              } else if (res.data.data[0].datasourceType == "MicroSoftServer") {
                sparkUrl
                  .post(`/datasource-connection/sql-server`, {
                    URL,
                    USERNAME,
                    PASSWORD,
                    QUERY,
                  })
                 .then((res) => {
                    setQuery("")
                    setSpin(false)
                    if (res.data.data == null) {
                      setPerson([{}]);
                    } else {
                      setPerson( res.data.data)
                    }
    
                    setMessege(res.data.message)
                    if (res.data.error == true) {
                      setValue(1)
                    } else {
                      setValue(0)
                    }
                  })
                  .catch((err) => {
                    setSpin(false);
                    setQuery("");
                  });
              }
            })
            .catch((err) => {
              console.log(err.response);
            });
        }
      };

     const saveAll = (e) => {
        var numUserId = localStorage.getItem("userId");
        var userId = `${numUserId}`;
        var workspaceId = localStorage.getItem("workspaceId");
    
        var tabName = JSON.parse(localStorage.getItem("tab"));
        var key = localStorage.getItem("key");
        if (key == 0) {
          var fileName = tabName[0].title;
        } else {
          var object = tabName.find((x) => x.key == key);
          var fileName = object.title;
        }
        var Content = code;
        baseUrl
          .post(
            `/storefile`,
            {
              fileName,
              Content,
              userId,
              workspaceId,
            },
            {
              headers: {
                Authorization: `Bearer ${localStorage.getItem("token")}`,
                contentType: "application/json",
                "Access-Control-Allow-Origin": "*",
              },
            }
          )
          .then((res) => {
            console.log(res);
          });
      };
      ////////////////////////////////////////////////
    let option;

    option = dataSources.map(function (records, i) {
        return { value: records.datasource_name, label: records.datasource_name };
      });

      const typeOfChart = [
        {
          value: "Select",
          label: "Bar Chart",
        },
        {
          value: "linechart",
          label: "Line Chart",
        },
        {
          value: "piechart",
          label: "Pie Chart",
        },
      ];

      var item = JSON.parse(localStorage.getItem("Json"));
      const checkedValue = checked;
      let AuthButton;
      if (chartType === "piechart") {
        AuthButton = <Donut data={person} />;
      } else if (chartType === "linechart") {
        AuthButton = <Linechart data={person} />;
      } else {
        AuthButton = <DevelopeChart data={person} />;
      }
      let spinner;
      let sizer;
      if (
        spin
          ? (spinner = (
              <>
                <Spin style={{ marginLeft: "90vh" }} />
              </>
            ))
          : (spinner = (
              <>
                <StickyHeadTable json={person} />
              </>
            ))
      )
        if (size === 40) {
          sizer = (
            <OpenWithIcon
              onClick={() => {
                if (size === 40) {
                  setSize(1)
                } else {
                  setSize(40)
                }
              }}
              style={{ marginLeft: "80%", marginTop: "10%" }}
            />
          );
        } else {
          sizer = (
            <KeyboardArrowDownIcon
              onClick={() => {
                if (size === 40) {
                    setSize(1)
                  } else {
                    setSize(40)
                  }
                }}
              style={{ marginLeft: "80%", marginTop: "10%" }}
            />
          );
        }

      
    return (
        <>
        <Button
          onClick={postAll}
          variant="contained"
          icon={<CaretRightOutlined />}
        >
          Run
        </Button>    
        <span style={{ marginLeft: "5%" }}>
          Use DataSource{" "}
          <Select
            className="btn col-md-2 select"
            options={option}
            onChange={handleDropdownChange}
          />
        </span>    
        <span style={{ float: "right" }}>
          <span style={{ marginBottom: 16, marginLeft: 10 }}>
            <Button onClick={Publish}>
              <i class="far fa-share-square mr-1"></i> Publish
            </Button>
          </span>
          <span style={{ marginBottom: 16, marginLeft: 10 }}>
            <Button onClick={saveAll}>
              <i class="far fa-save mr-1"></i> Save
            </Button>
          </span>
          <span style={{ marginBottom: 16, marginLeft: 10 }}>
            <Button onClick={clearAll}>
              <i class="far fa-trash-alt mr-1"></i> Discard all
            </Button>
          </span>
          <span style={{ marginBottom: 16, marginLeft: 10 }}>
            <Button onClick={refreshPage}>
              <i class="fas fa-redo-alt mr-1"></i>
              Refresh
            </Button>
          </span>
        </span>
        <div className="border border-dark">
          <Editor
            id="editor"
            value={code}
            onValueChange={(code) => setCode(code)}
            onMouseUpCapture={(e) => handleMouseEvent(e)}
            highlight={(code) => highlight(code, languages.js)}
            padding={10}
            style={{
              fontFamily: '"Fira code", "Fira Mono", monospace',
              fontSize: 12,
              height: `${size}vh`,
            }}
          />
        </div>
        <Paper square>
          <Tabs
            value={value}
            onChange={handleChangeTab}
            textColor="primary"
            indicatorColor="primary"
            aria-label="nav tabs example"
          >
            <LinkTab
              label="Result"
              className="tabs"
              href="/result"
              {...a11yProps(0)}
            />
            <LinkTab
              label="Messages"
              className="tabs"
              href="/messages"
              {...a11yProps(1)}
            />
          </Tabs>
        </Paper>

        {/* ////////////////////////////////////////////////// */}
        <TabPanel value={value} index={1}>
          <p className="">{messege}</p>
        </TabPanel>
        <TabPanel value={value} index={0}>
          <FormGroup style={{ marginLeft: "160vh" }}>
            <Typography component="div" style={{ marginTop: "-7vh" }}>
              <Grid component="label" container alignItems="center" spacing={1}>
                <Grid item>Table</Grid>
                <Grid item>
                  <AntSwitch
                    checked={checked}
                    onChange={handleChange}
                    name="checkedC"
                  />
                </Grid>
                <Grid item>Chart</Grid>
              </Grid>
            </Typography>
            {sizer}
          </FormGroup>

          <span style={{ marginLeft: "95%" }}></span>
          <CsvDownload data={person} className="btn btn-sm">
            CSV
            <i className="fas fa-download" />
          </CsvDownload>
          <div>
            <div>
              {checked ? (
                <>
                  <span>
                    <b>Chart Type</b> :{" "}
                    <Select
                      className="btn col-md-2"
                      onChange={handleChartChange}
                      options={typeOfChart}
                    />
                  </span>
                  <div style={{ display: "flex", justifyContent: "center" }}>
                    {AuthButton}
                  </div>
                </>
              ) : (
                <>{spinner}</>
              )}
            </div>

          </div>
        </TabPanel>

        <Popupapi
          openPopup={restGet}
          setOpenPopup={close}
          title="REST API"
        >
          <Restapi />
        </Popupapi>
        
        </>
    )
}

export default FunctionEditor;
