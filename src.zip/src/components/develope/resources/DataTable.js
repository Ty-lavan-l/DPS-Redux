import React, { useState, useEffect } from "react";
import axios from "axios";
import fileDownload from "js-file-download";
import {
  makeStyles,
  TableBody,
  TableRow,
  TableCell,
  Toolbar,
  Fab,
  Table,
  Avatar,
} from "@material-ui/core";
import useTable from "../../controls/useTable";
import DeleteIcon from "@material-ui/icons/Delete";
import Popup from "../../controls/Popup";
import Popupdev from "../../controls/Popupdev";
import PopupView from "../../controls/PopupView";
import Notification from "../../controls/Notification";
import ConfirmDialog from "../../controls/ConfirmDialog";
import EditIcon from "@material-ui/icons/Edit";
import RewardsForm from "./DataTable";
import { Card } from "@material-ui/core";
import VisibilityIcon from "@material-ui/icons/Visibility";
import * as ReactBoostrap from "react-bootstrap";
import Popupsnowflake from "../../controls/Popupsnowflake";
import GetAppIcon from "@material-ui/icons/GetApp";
import ShareIcon from "@material-ui/icons/Share";

import {
  Form,
  Button,
  FormGroup,
  FormControl,
  ControlLabel,
} from "react-bootstrap";
import { Spin } from "antd";
import { baseUrl } from "../../controls/axios";
const useStyles = makeStyles((theme) => ({
  root: {},
}));

const headCells = [{ id: "datasourceName", label: " " }];

export default function Rewards({ reloading }) {
  let access_token = localStorage.getItem("token");
  let userId = localStorage.getItem("userId");
  const data = {
    datasourceName: "",
    userId: `${userId}`,
    url: "",
    port: "",
    userName: "",
    password: "",
  };

  const classes = useStyles();
  const [values, setValues] = useState(data);
  const [openPopup, setOpenPopup] = useState(false);
  const [openPopup1, setOpenPopup1] = useState(false);
  const [openPopupsnow, setOpenPopupsnow] = useState(false);
  const [edit, setEdit] = useState([]);
  const [reload, setReload] = useState(false);
  const [loading, setLoading] = useState(false);
  const [openPopups, setOpenpopups] = useState(false);
  const [sorted, setSorted] = useState([]);
  const [flate, setFlate] = useState([]);
  const [update,
    setUpdate] = useState({
      datasourceName: "",
      userId: `${userId}`,
      datasourceId: "",
      accountNo: "",
      url: "",
      port: "",
      userName: "",
      password: "",
    });

  const [notify, setNotify] = useState({
    isOpen: false,
    message: "",
    type: "",
  });

  const [confirmDialog, setConfirmDialog] = useState({
    isOpen: false,
    title: "",
    subTitle: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUpdate({
      ...update,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    baseUrl
      .post("/data-source/update-datasource", update,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
      .then((response) => {
        console.log("Status: ", response.status);
        console.log("this is axios", response.data);
        setReload(!reload);
        setNotify({
          isOpen: true,
          message: `Datasource updated Successfully`,
          type: "success",
        });
        setOpenPopupsnow(false);
        setOpenPopup(false);
      })
      .catch((error) => {
        console.error("Something went wrong!", error);
      });
  };

  const [records, setRecords] = useState([]);
  const [result, setResult] = useState("");
  const [hovered, setHovered] = useState(false);
  const toggleHover = () => setHovered(!hovered);

  const { TblContainer, TblHead, TblPagination, recordsAfterPagingAndSorting } =
    useTable(records, headCells);
  // ******Services********
  useEffect(() => {
    getAll();
  }, [reload, reloading]);
  const [flatSorted, setFlatSorted] = useState([]);
  function getAll() {
    baseUrl
      .get(`/user/${userId}` ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
      .then((res) => {
        setRecords(
          res.data.data[0].datasource.filter(function (item) {
            return (item =
              item.port != null &&
              item.userName != null &&
              item.url != null &&
              item.password != null);
          })
        );
        setSorted(
          res.data.data[0].datasource.filter(function (item) {
            return (item =
              item.port != null &&
              item.userName != null &&
              item.url != null &&
              item.password != null);
          })
        );

        setFlate(
          res.data.data[0].datasource.filter(function (items) {
            return (items =
              items.port == null &&
              items.userName == null &&
              items.url == null &&
              items.password == null);
          })
        );
        setFlatSorted(
          res.data.data[0].datasource.filter(function (items) {
            return (items =
              items.port == null &&
              items.userName == null &&
              items.url == null &&
              items.password == null);
          })
        );
      })
      .catch((err) => {
        console.log(err);
      });
  }
  let a = [];
  let b = [];
  function handleSort(event) {
    a = records.filter((e) =>
      e.datasourceName.toLowerCase().includes(event.target.value.toLowerCase())
    );
    setSorted(a);
    b = flatSorted.filter((e) =>
      e.datasourceName.toLowerCase().includes(event.target.value.toLowerCase())
    );
    setFlate(b);
  }

  const onDelete = (item) => {
    setConfirmDialog({
      ...confirmDialog,
      isOpen: false,
    });

    console.log("this is item ", item);
    const data = item;
    baseUrl
      .get(`/datasource1/${item}` ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
      .then((res) => {
        setResult(res);
        setNotify({
          isOpen: true,
          message: `Record Deleted`,
          type: "success",
        });
        setReload(!reload);
        setLoading(true);
      })
      .catch((err) => {
        setResult(err);
        setNotify({
          isOpen: true,
          message: `failed to delete`,
          type: "error",
        });
      });
  };

  const onView = (items) => {
    baseUrl
      .get(`/data-source/download/datasource/${items}` ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
      .then((res) => {
        console.log("this is view", res);
        fileDownload(res.data, "report.csv");
      })
      .catch((err) => {
        setResult(err);
      });
  };
  const onDeleteFlat = (items) => {
    setConfirmDialog({
      ...confirmDialog,
      isOpen: false,
    });
    const data = items;
    baseUrl
      .get(`/datasource1/${items}` ,{
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      }
)
      .then((res) => {
        setResult(res);
        setNotify({
          isOpen: true,
          message: `Record Deleted`,
          type: "success",
        });
        setReload(!reload);
        setLoading(true);
      })
      .catch((err) => {
        setResult(err);
        setNotify({
          isOpen: true,
          message: `failed to delete`,
          type: "error",
        });
      });
  };
  const openInPopup = (item) => {
    const result = records.filter((id) => id.datasourceId == item);
    console.log(result);
    setEdit(result);
    console.log(edit);
    setOpenPopup(true);
    setUpdate({
      datasourceName: result[0].datasourceName,
      datasourceId: result[0].datasourceId,
      userId: `${userId}`,
      url: result[0].url,
      port: result[0].port,
      userName: result[0].userName,
      password: result[0].password,
    });
  };
  const openInPopupsnow = (item) => {
    const result = records.filter((id) => id.datasourceId == item);
    console.log(result);
    setEdit(result);
    console.log(edit);
    setOpenPopupsnow(true);
    setUpdate({
      datasourceName: result[0].datasourceName,
      datasourceId: result[0].datasourceId,
      userId: `${userId}`,
      url: result[0].url,
      port: result[0].port,
      accountNo: result[0].accountNo,
      userName: result[0].userName,
      password: result[0].password,
    });
  };
  const openInPopup1 = (item) => {
    const result = records.filter((id) => id.datasourceId == item);
    console.log(item);
    console.log(result);
    setEdit(result);
    console.log(edit);
    setOpenPopup1(true);
  };
  const openInPopups = (item) => {
    const result = records.filter((id) => id.datasourceId == item);
    console.log(item);
    console.log(result);
    setEdit(result);
    console.log(edit);
    setOpenpopups(true);
  };
  let spinner;
  if (
    records.length == 0
      ? (spinner = <Spin className="mt-3" style={{ marginLeft: "21vh" }} />)
      : (spinner = <></>)
  )
    return (
      <>
        <Card className="home-Card">
          <input
            style={{ height: "50px" }}
            type="text"
            className="form-control"
            placeholder="filter resources by name"
            aria-label="Reference"
            aria-describedby="basic-addon2"
            onChange={(e) => {
              handleSort(e);
            }}
          />
          {spinner}
          <Table>
            <div style={{ height: "20vh", overflowY: "scroll" }}>
              <TableBody>
                {sorted.map((item) => (
                  <TableRow>
                    <TableCell>{item.datasourceName}</TableCell>
                    <TableCell>
                      <Fab
                        className={hovered ? "pulse animated" : ""}
                        onMouseEnter={toggleHover}
                        onMouseLeave={toggleHover}
                        style={{ backgroundColor: "white" }}
                        size="small"
                        aria-label="edit"
                        onClick={() => {
                          if (item.accountNo != null) {
                            openInPopupsnow(item.datasourceId);
                          } else openInPopup(item.datasourceId);
                        }}
                      >
                        <EditIcon />
                      </Fab>
                    </TableCell>
                    <TableCell>
                      <Fab
                        style={{
                          backgroundColor: "white",
                          // marginLeft: "10px",
                          color: "primary",
                        }}
                        size="small"
                        aria-label="delete"
                        onClick={() => {
                          setConfirmDialog({
                            isOpen: true,
                            title: "Are you sure to delete this record?",
                            subTitle: "You can't undo this operation",
                            onConfirm: () => {
                              onDelete(item.datasourceId);
                            },
                          });
                        }}
                      >
                        <DeleteIcon />
                      </Fab>
                    </TableCell>
                    <TableCell>
                      <Fab
                        style={{ backgroundColor: "white" }}
                        size="small"
                        aria-label="edit"
                        onClick={() => {
                          if (item.accountNo != null) {
                            openInPopups(item.datasourceId);
                          } else openInPopup1(item.datasourceId);
                        }}
                      >
                        <VisibilityIcon />
                      </Fab>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </div>
          </Table>
          <b>File :</b>
          <div style={{ height: "20vh", overflow: "scroll" }}>
            {flate.map((items) => (
              <TableRow>
                <TableCell>{items.datasourceName}</TableCell>
                <TableCell>
                  <Fab
                    style={{
                      backgroundColor: "white",
                      marginLeft: "10px",
                    }}
                    size="small"
                    aria-label="delete"
                    onClick={() => {
                      setConfirmDialog({
                        isOpen: true,
                        title: "Are you sure to delete this record?",
                        subTitle: "You can't undo this operation",
                        onConfirm: () => {
                          onDeleteFlat(items.datasourceId);
                        },
                      });
                    }}
                  >
                    <DeleteIcon />
                  </Fab>
                </TableCell>
                <TableCell>
                  <Fab
                    style={{ backgroundColor: "white" }}
                    size="small"
                    aria-label="edit"
                    onClick={() => onView(items.datasourceId)}
                  >
                    <GetAppIcon />
                  </Fab>
                </TableCell>
              </TableRow>
            ))}
          </div>
          <Popupsnowflake
            title="Edit Datasource "
            openPopupsnow={openPopupsnow}
            setOpenPopupsnow={setOpenPopupsnow}
          >
            <div>
              <Form onSubmit={handleSubmit}>
                <div className="form-group row">
                  <label
                    htmlFor="datasourceName"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Name of Datasource
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      pattern="[^' ']+"
                      title="No space allowed"
                      className="form-control sqlinput"
                      name="datasourceName"
                      value={update.datasourceName}
                      onChange={handleInputChange}
                      placeholder="Enter Name of database"
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="url"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Url
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      name="url"
                      value={update.url}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Url"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="port"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Port
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="number"
                      name="port"
                      value={update.port}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Port No"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="accountNo"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Account No
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      name="accountNo"
                      value={update.accountNo}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Account No"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="username"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    UserName
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      name="userName"
                      value={update.userName}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Username"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="password"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Password
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="password"
                      name="password"
                      value={update.password}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Password"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="btn btn-primary linkbtn"
                >
                  Submit
                </button>
              </Form>
              <Notification notify={notify} setNotify={setNotify} />
            </div>
          </Popupsnowflake>

          <Popup
            title="Edit Datasource"
            openPopup={openPopup}
            setOpenPopup={setOpenPopup}
          >
            <div>
              <Form onSubmit={handleSubmit}>
                <div className="form-group row">
                  <label
                    htmlFor="datasourceName"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Name of Datasource
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      pattern="[^' ']+"
                      title="No space allowed"
                      className="form-control sqlinput"
                      name="datasourceName"
                      value={update.datasourceName}
                      onChange={handleInputChange}
                      placeholder="Enter Name of database"
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="url"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Url
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      name="url"
                      value={update.url}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Url"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="port"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Port
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="number"
                      name="port"
                      value={update.port}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Port No"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="username"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    UserName
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="text"
                      name="userName"
                      value={update.userName}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Username"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <div className="form-group row">
                  <label
                    htmlFor="password"
                    className="col-sm-3 col-form-label sqlLable"
                  >
                    Password
                  </label>
                  <div className="col-sm-8">
                    <input
                      type="password"
                      name="password"
                      value={update.password}
                      onChange={handleInputChange}
                      className="form-control sqlinput"
                      placeholder="Enter Password"
                      defaultValue=""
                      required
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="btn btn-primary linkbtn"
                >
                  Submit
                </button>
              </Form>
            </div>
          </Popup>
          <Popupdev
            title="Datasource Details"
            openPopup={openPopup1}
            setOpenPopup={setOpenPopup1}
          >
            {edit.map((item) => (
              <ul class="list-group list-group-flush" key={item.datasourceId}>
                <li class="list-group-item">
                  <b>Datasource Name</b> :{item.datasourceName}
                </li>
                <li class="list-group-item">
                  <b> URL</b> :{item.url}
                </li>
                <li class="list-group-item">
                  <b>Port</b> :{item.port}
                </li>
                <li class="list-group-item">
                  <b>User Name</b> :{item.userName}
                </li>
              </ul>
            ))}
          </Popupdev>
          <PopupView
            title="Datasource Details"
            openPopups={openPopups}
            setOpenPopups={setOpenpopups}
          >
            {edit.map((item) => (
              <ul class="list-group list-group-flush" key={item.datasourceId}>
                <li class="list-group-item">
                  <b>Datasource Name</b> :{item.datasourceName}
                </li>
                <li class="list-group-item">
                  <b> URL</b> :{item.url}
                </li>
                <li class="list-group-item">
                  <b>Port</b> :{item.port}
                </li>
                <li class="list-group-item">
                  <b>Account Number</b> :{item.accountNo}
                </li>
                <li class="list-group-item">
                  <b>User Name</b> :{item.userName}
                </li>
              </ul>
            ))}
          </PopupView>

          <Notification notify={notify} setNotify={setNotify} />
          <ConfirmDialog
            confirmDialog={confirmDialog}
            setConfirmDialog={setConfirmDialog}
          />
        </Card>
      </>
    );
}
