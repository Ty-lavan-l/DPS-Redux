import React from 'react';
import PrivateRoutes from './PrivateRoutes';



function PrivateSection() {
   
    return (
       <PrivateRoutes />
    );
}

export default PrivateSection;
