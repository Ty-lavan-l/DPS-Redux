import React from 'react';
import LoginPage from '../components/loginform/LoginPage';
import Routing from '../components/dashboard/Routing';
function Routes() {
    let isUserLoggedIn = false;

    if (localStorage.getItem('token')) {
        isUserLoggedIn = true;
    } else {
        isUserLoggedIn = false;
    }

    return isUserLoggedIn ? <Routing /> : <LoginPage />;
}

export default Routes;
