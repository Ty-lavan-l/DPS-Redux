import { createSlice } from '@reduxjs/toolkit';

const initialState = {sqlScript: []}

const develpoeSlice = createSlice({
    name:'develope',
    initialState,
    reducers : {
        sqlScript(state, action) {
            state.sqlScript = action.payload
        },
    }
})

export const developeActions = develpoeSlice.actions


export default develpoeSlice.reducer 

