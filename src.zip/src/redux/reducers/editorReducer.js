import { createSlice } from '@reduxjs/toolkit';

const initialState = {code: ""}

const editorSlice = createSlice({
    name:'login',
    initialState,
    reducers : {
        dataSourcesAction(state, action) {
          
        },
        fileContent(state, action) {
            state.code = action.payload.data
        }
       
    }
})

export const editorActions = editorSlice.actions


export default editorSlice.reducer 

