import { createSlice } from '@reduxjs/toolkit';

const initialState = {records: [], message : "", loader : true, modal : false, dependency:""}

const dashboardSlice = createSlice({
    name:'dashboard',
    initialState,
    reducers : {
        workspaces(state, action) {
            state.records = action.payload.records
            if (action.payload == 0) {
                state.message = "No Record Found"
            }
            state.loader = action.spiner
        },
        createWorkspace(state, action) {
            state.modal = action.payload.modal
            state.dependency = action.payload.dependency
        }
    }
})

export const dashboardActions = dashboardSlice.actions


export default dashboardSlice.reducer 

