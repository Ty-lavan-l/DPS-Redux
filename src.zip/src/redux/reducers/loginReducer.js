import { createSlice } from '@reduxjs/toolkit';

const initialState = {login: false, loginPage: true,data: []}

const loginSlice = createSlice({
    name:'login',
    initialState,
    reducers : {
        login(state, action) {
            state.login = true
            state.data = action.payload
        },
        logout(state) {
            state.login = false
            state.data = []
        },
        loginPage(state) {
            state.loginPage = true
        },
        RegistrationPage (state) {
            state.loginPage = false
        }
    }
})

export const loginActions = loginSlice.actions


export default loginSlice.reducer 

