import { createSlice } from '@reduxjs/toolkit';
let userId = localStorage.getItem("userId");

const initialState = {awsRedShift : {
    datasourceType: "AwsRedShift",
    datasourceName: "",
    userId: `${userId}`,
    url: "",
    port: "",
    userName: "",
    password: "",
  }, mySql : {
    datasourceType: "Mysql",
    datasourceName: "",
    userId: `${userId}`,
    url: "",
    port: "",
    userName: "",
    password: "",
  },
  microsoftSqlServer: {
    datasourceType: "MicroSoftServer",
    datasourceName: "",
    userId: `${userId}`,
    url: "",
    port: "",
    userName: "",
    password: "",
  },
  snowFlake : {
    datasourceType: "SnowFlake",
    datasourceName: "",
    url: "",
    port: "",
    userId: `${userId}`,
    userName: "",
    accountNo: "",
    password: "",
  }
}

const formSlice = createSlice({
    name:'form',
    initialState,
    reducers : {
        awsRedShift(state, action) {
          state.awsRedShift = action.payload
        },
        mySql(state, action) {
            state.mySql = action.payload
          },
        microsoftSqlServer(state, action) {
            state.microsoftSqlServer = action.payload
        },
        snowFlake(state, action) {
            state.snowFlake = action.payload
          },
        
    }
})

export const formActions = formSlice.actions


export default formSlice.reducer 

