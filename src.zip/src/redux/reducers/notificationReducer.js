import { createSlice } from '@reduxjs/toolkit';

const initialState = {notification: false, message: '', type:''}

const notificationSlice = createSlice({
    name:'notification',
    initialState,
    reducers : {
        setNotification(state, action) {
            state.notification = action.payload.state;
            state.message = action.payload.message;
            state.type = action.payload.type
        }
    }
})

export const notificationActions = notificationSlice.actions
export default notificationSlice.reducer 