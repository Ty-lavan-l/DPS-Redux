import { configureStore } from '@reduxjs/toolkit';

import loginSlice from './reducers/loginReducer';
import notificationSlice from './reducers/notificationReducer'
import dashboardSlice from './reducers/dashboardReducers'
import formSlice from './reducers/formreducers'
import develpoeSlice from './reducers/developeReducers'
import editorSlice from './reducers/editorReducer'
const store = configureStore({
  reducer: {
     login: loginSlice, 
     notification : notificationSlice, 
     dashboard : dashboardSlice, 
     formModule : formSlice,
     developeModule : develpoeSlice,
     editor : editorSlice
    },
});

export default store;
