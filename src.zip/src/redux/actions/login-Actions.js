import { baseUrl } from "../../components/controls/axios";
import {loginActions} from '../reducers/loginReducer'
import {notificationActions} from '../reducers/notificationReducer'


export const LoginAuthentication = (loginData) => {
    return function (dispatch) { 
    baseUrl
      .post("/authenticate", {
        mailId: loginData.mailId,
        password: loginData.password,
      })
        .then((res) => {
          localStorage.setItem("token", res.data.token);
          localStorage.setItem("username", res.data.data[0].userName);
          localStorage.setItem("userId", res.data.data[0].userId);
          localStorage.setItem("mailId", res.data.data[0].mailId);
          localStorage.setItem("tab", JSON.stringify([{ title: ``, key: "" }]));
          localStorage.setItem("key", 0);
          localStorage.setItem("size", 1);
          localStorage.setItem("refresh", false)
          localStorage.setItem("workspaceId", 0);
          localStorage.setItem(
            "flatfile",
            JSON.stringify([{ title: ``, key: `` }])
          );
          localStorage.setItem("Json", JSON.stringify([{}]));
          localStorage.setItem("result", JSON.stringify([{}]));
            // Dispatch Actions
          dispatch(loginActions.login(res.data))
          dispatch(notificationActions.setNotification({state: true, message: 'Login Successfully', type:'success'}))

        })
        .catch((res) => {
          dispatch(loginActions.login(res.data))
          dispatch(notificationActions.setNotification({state: true, message: 'please enter a valid email address and password', type:'error'}))
        })
    }
  }

  export const signUpAction = (existUser,newUser) => {
    return function (dispatch) { 
      baseUrl
      .post(`/user/existing-user`, {
        mailId: existUser.mailId,
      }).then((res) => {
        dispatch(notificationActions.setNotification({state: true, message: 'Email Already in use!', type:'error'}))
      }).catch((err) => {
        baseUrl
        .post(`/register`, newUser)
        .then((res) => {
          dispatch(notificationActions.setNotification({state: true, message: 'Registered  Successfully', type:'success'}));
          dispatch(loginActions.loginPage());
        }).catch((err) => {
        dispatch(notificationActions.setNotification({state: true, message: 'Registeration failed', type:'error'}));
        })
      })
    }
  }

