import { baseUrl } from "../../components/controls/axios";
import { notificationActions } from "../reducers/notificationReducer";
import {developeActions} from '../reducers/developeReducers'

export const sqlScript = (values) => {
    return function (dispatch) {
        baseUrl
        .post("/sql-script/sqlscript", values ,{
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          }
        })
        .then((res) => {
            dispatch(developeActions.sqlScript(res))
            dispatch(notificationActions.setNotification({state: true, message: 'Datasource added Successfully', type:'success'}))
             
          }).catch((err) => {
            dispatch(notificationActions.setNotification({state: true, message: 'Datasource name should be unique', type:'success'}))
  
            console.log(err.response);
          })
      }
    }
  