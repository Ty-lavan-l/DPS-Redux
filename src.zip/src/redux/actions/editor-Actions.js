import { baseUrl } from "../../components/controls/axios";
import { editorActions } from "../reducers/editorReducer";
import { notificationActions } from "../reducers/notificationReducer";


export const getAllWorkspace = () => {
var userId = localStorage.getItem("userId");

    return function (dispatch) { 
        baseUrl
        .get(`/user/${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          },
        })
        .then((res) => {
            dispatch(editorActions.dataSourcesAction(res.data))
        }).catch((err) => {
            console.log(err.response);
        })
    }
  }


  export const fileContent = (fileName,workspaceId) => {
    
        return function (dispatch) { 
            baseUrl
            .get(`/file-content/${fileName}/${workspaceId}`,{
                headers: {
                  Authorization: `Bearer ${localStorage.getItem("token")}`,
                  contentType: "application/json",
                  "Access-Control-Allow-Origin": "*",
                }
              })
            .then((res) => {
                if (res.data.data == null) {
                    dispatch(editorActions.fileContent(''))
                } else {
                    dispatch(editorActions.fileContent(res.data.data))
                }
            }).catch((err) => {
                console.log(err.response);
            })
        }
      }