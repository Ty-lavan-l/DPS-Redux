import { baseUrl } from "../../components/controls/axios";
import {dashboardActions} from '../reducers/dashboardReducers'
import {notificationActions} from '../reducers/notificationReducer'

  export const getAllWorkspace = (userId) => {
    return function (dispatch) { 
        baseUrl
        .get(`/user/${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json;charset=UTF-8",
            "Access-Control-Allow-Origin": "*",
          },
        }).then((res) => {
            dispatch(dashboardActions.workspaces({records :res.data.data[0].workspace}, {spiner :false}))
        }).catch((err) => {
            console.log(err.response);
        })
    }
  }

  export const addWorkspace = (values, data) => {
    return function (dispatch) { 
       
        baseUrl
        .post("/workspace/workspace", values, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            contentType: "application/json",
            "Access-Control-Allow-Origin": "*",
          }
        })
        .then((res) => {
            localStorage.setItem("workspaceId", res.data.data[0].workspaceId);
            dispatch(dashboardActions.createWorkspace({data : data}))
            dispatch(dashboardActions.createWorkspace({modal : false}, {dependency: res}))
            dispatch(notificationActions.setNotification({state: true, message: 'Workspace Added Successfully', type:'success'}))
        }).catch((err) => {
            console.log(err.response);
            dispatch(dashboardActions.createWorkspace({modal : true}))
          dispatch(notificationActions.setNotification({state: true, message: 'Workspace Name should be unique', type:'error'}))
        })
    }
  }


