import { baseUrl } from "../../components/controls/axios";
import { formActions } from "../reducers/formreducers";
import { notificationActions } from "../reducers/notificationReducer";


export const awsRedShift = (values, ...data) => {
    return function (dispatch) { 
      baseUrl
      .post("/data-source/datasource", values, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
          contentType: "application/json",
          "Access-Control-Allow-Origin": "*",
        }
      })
        .then((res) => {
          dispatch(formActions.awsRedShift(...data))
          dispatch(notificationActions.setNotification({state: true, message: 'Datasource added Successfully', type:'success'}))
           
        }).catch((err) => {
          dispatch(notificationActions.setNotification({state: true, message: 'Datasource name should be unique', type:'success'}))

          console.log(err.response);
        })
    }
  }


  
export const microsoftSqlServer = (values, ...data) => {
  return function (dispatch) { 
    baseUrl
    .post("/data-source/datasource", values, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        contentType: "application/json",
        "Access-Control-Allow-Origin": "*",
      }
    })
      .then((res) => {
        dispatch(formActions.microsoftSqlServer(...data))
        dispatch(notificationActions.setNotification({state: true, message: 'Datasource added Successfully', type:'success'}))
         
      }).catch((err) => {
        dispatch(notificationActions.setNotification({state: true, message: 'Datasource name should be unique', type:'success'}))

        console.log(err.response);
      })
  }
}

export const mySql = (values, ...data) => {
  return function (dispatch) { 
    baseUrl
    .post("/data-source/datasource", values, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        contentType: "application/json",
        "Access-Control-Allow-Origin": "*",
      }
    })
      .then((res) => {
        dispatch(formActions.mySql(...data))
        dispatch(notificationActions.setNotification({state: true, message: 'Datasource added Successfully', type:'success'}))
         
      }).catch((err) => {
        dispatch(notificationActions.setNotification({state: true, message: 'Datasource name should be unique', type:'success'}))

        console.log(err.response);
      })
  }
}

export const snowFlake = (values, ...data) => {
  return function (dispatch) { 
    baseUrl
    .post("/data-source/datasource", values, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
        contentType: "application/json",
        "Access-Control-Allow-Origin": "*",
      }
    })
      .then((res) => {
        dispatch(formActions.snowFlake(...data))
        dispatch(notificationActions.setNotification({state: true, message: 'Datasource added Successfully', type:'success'}))
         
      }).catch((err) => {
        dispatch(notificationActions.setNotification({state: true, message: 'Datasource name should be unique', type:'success'}))

        console.log(err.response);
      })
  }
}