// import React from 'react';

// const MyContext = React.createContext();

// export default class MyProvider extends React.Component {
//     state = {
//       name: "Wes",
//       age: 100,
//       cool: true
//     };
//     render() {
//       return (
//         <MyContext.Provider
//           value={{
//             state: this.state,
//             changeMood: () =>
//               this.setState({
//                 cool: !this.state.cool
//               }),
//             growAYearOlder: () =>
//               this.setState({
//                 age: this.state.age + 1
//               })
//           }}
//         >
//           {this.props.children}
//         </MyContext.Provider>
//       );
//     }
//   }

import React from "react";
import Context from "./UserContext";

class Provider extends React.Component {
  state = {
    name: "Batman"
  };

  render() {
    return (
      <Context.Provider
        value={{
          name: this.state.name,
          updateName: name => this.setState({ name })
        }}
      >
        {this.props.children}
      </Context.Provider>
    );
  }
}

export default Provider;
