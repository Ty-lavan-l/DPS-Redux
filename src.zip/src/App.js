import React, { useState, useEffect } from "react";
import { BrowserRouter as Router } from 'react-router-dom';
import Routes from './routes';
import Notification from "./components/controls/Notification";
import { useSelector, useDispatch } from 'react-redux';
import { notificationActions } from "./redux/reducers/notificationReducer";
import CodeEditor from "./components/develope/resources/Editor";
import TabPanel from './components/develope/resources/FunctionEditor'
export default function App() {
    const [notify, setNotify] = useState({
        islogged: false,
        message: "",
        type: "",
      });
    const showCart = useSelector((state) => state.notification);
    const dispatch = useDispatch();

    
  useEffect(() => {
    setNotify({
      isOpen: showCart.notification,
      message: showCart.message,
      type: showCart.type,
    });
    setTimeout(function(){
      dispatch(notificationActions.setNotification({state: false, message: '', type:''}))
   }, 5000);

  }, [showCart.notification,showCart.message,showCart.type, dispatch])

    return (
        <div className='parentDiv'>
            {/* <Router>
                <Routes className='default-search' />
            </Router>
        <Notification notify={notify} setNotify={setNotify} /> */}
        <CodeEditor/>

        </div>
    );
}
